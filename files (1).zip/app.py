from flask import Flask, request, jsonify, session, render_template_string, redirect
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3
import os
import uuid
import json
from datetime import datetime, timedelta

# ============================================================
# ORBIT - FULL STACK SOCIAL MEDIA APP
# Frontend + Backend + SQLite in ONE FILE
# ============================================================

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "CHANGE_THIS_CONNECTX_SECRET_KEY_2026")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "connectx.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp", "mp4", "webm", "mov"}

# ============================================================
# DATABASE
# ============================================================

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        bio TEXT DEFAULT 'Welcome to Orbit',
        avatar TEXT DEFAULT '',
        profile_music_url TEXT DEFAULT '',
        profile_music_name TEXT DEFAULT '',
        is_private INTEGER DEFAULT 0,
        is_verified INTEGER DEFAULT 0,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        media_url TEXT NOT NULL,
        media_type TEXT NOT NULL,
        caption TEXT DEFAULT '',
        music_url TEXT DEFAULT '',
        music_name TEXT DEFAULT '',
        filter_name TEXT DEFAULT '',
        overlay_text TEXT DEFAULT '',
        views INTEGER DEFAULT 0,
        location TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS likes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        post_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(user_id, post_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        post_id INTEGER NOT NULL,
        comment TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS follows (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        follower_id INTEGER NOT NULL,
        following_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(follower_id, following_id),
        FOREIGN KEY(follower_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(following_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS saved_posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        post_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(user_id, post_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER NOT NULL,
        receiver_id INTEGER NOT NULL,
        message TEXT NOT NULL,
        image_url TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(receiver_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        actor_id INTEGER,
        notification_type TEXT NOT NULL,
        text TEXT NOT NULL,
        is_read INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(actor_id) REFERENCES users(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS stories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        media_url TEXT NOT NULL,
        media_type TEXT DEFAULT 'image',
        music_url TEXT DEFAULT '',
        music_name TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS highlights (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        media_url TEXT NOT NULL,
        media_type TEXT DEFAULT 'image',
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS follow_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        requester_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(requester_id, target_id),
        FOREIGN KEY(requester_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(target_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS close_friends (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        friend_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(user_id, friend_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(friend_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS blocked_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        blocked_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(user_id, blocked_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(blocked_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS muted_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        muted_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(user_id, muted_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(muted_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS post_media (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        post_id INTEGER NOT NULL,
        media_url TEXT NOT NULL,
        media_type TEXT NOT NULL,
        position INTEGER DEFAULT 0,
        FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS call_signals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        from_id INTEGER NOT NULL,
        to_id INTEGER NOT NULL,
        signal_type TEXT NOT NULL,
        payload TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(from_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(to_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reporter_id INTEGER NOT NULL,
        target_type TEXT NOT NULL,
        target_id INTEGER NOT NULL,
        reason TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        created_at TEXT NOT NULL,
        FOREIGN KEY(reporter_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS reset_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        token TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        used INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    """)
    conn.commit()

    existing_user_cols2 = [row["name"] for row in conn.execute("PRAGMA table_info(users)").fetchall()]
    if "comments_enabled" not in existing_user_cols2:
        conn.execute("ALTER TABLE users ADD COLUMN comments_enabled INTEGER DEFAULT 1")
    if "is_verified" not in existing_user_cols2:
        conn.execute("ALTER TABLE users ADD COLUMN is_verified INTEGER DEFAULT 0")
    if "is_admin" not in existing_user_cols2:
        conn.execute("ALTER TABLE users ADD COLUMN is_admin INTEGER DEFAULT 0")
    conn.commit()

    # Safe migration for existing databases (adds columns if missing)
    existing_cols = [row["name"] for row in conn.execute("PRAGMA table_info(posts)").fetchall()]
    if "music_url" not in existing_cols:
        conn.execute("ALTER TABLE posts ADD COLUMN music_url TEXT DEFAULT ''")
    if "music_name" not in existing_cols:
        conn.execute("ALTER TABLE posts ADD COLUMN music_name TEXT DEFAULT ''")
    if "filter_name" not in existing_cols:
        conn.execute("ALTER TABLE posts ADD COLUMN filter_name TEXT DEFAULT ''")
    if "overlay_text" not in existing_cols:
        conn.execute("ALTER TABLE posts ADD COLUMN overlay_text TEXT DEFAULT ''")
    if "views" not in existing_cols:
        conn.execute("ALTER TABLE posts ADD COLUMN views INTEGER DEFAULT 0")
    if "location" not in existing_cols:
        conn.execute("ALTER TABLE posts ADD COLUMN location TEXT DEFAULT ''")

    existing_user_cols = [row["name"] for row in conn.execute("PRAGMA table_info(users)").fetchall()]
    if "profile_music_url" not in existing_user_cols:
        conn.execute("ALTER TABLE users ADD COLUMN profile_music_url TEXT DEFAULT ''")
    if "profile_music_name" not in existing_user_cols:
        conn.execute("ALTER TABLE users ADD COLUMN profile_music_name TEXT DEFAULT ''")

    existing_msg_cols = [row["name"] for row in conn.execute("PRAGMA table_info(messages)").fetchall()]
    if "image_url" not in existing_msg_cols:
        conn.execute("ALTER TABLE messages ADD COLUMN image_url TEXT DEFAULT ''")

    existing_story_cols = [row["name"] for row in conn.execute("PRAGMA table_info(stories)").fetchall()]
    if "music_url" not in existing_story_cols:
        conn.execute("ALTER TABLE stories ADD COLUMN music_url TEXT DEFAULT ''")
    if "music_name" not in existing_story_cols:
        conn.execute("ALTER TABLE stories ADD COLUMN music_name TEXT DEFAULT ''")
    conn.commit()

    # Demo users
    demo_users = [
        ("Rahul Developer", "rahul_dev", "rahul@connectx.local", "Rahul@123"),
        ("Sneha Creates", "sneha_creates", "sneha@connectx.local", "Sneha@123"),
        ("Aman Tech", "aman.tech", "aman@connectx.local", "Aman@123"),
        ("Vishal", "vishal", "vishal@connectx.local", "Vishal@123"),
        ("Ananya", "ananya", "ananya@connectx.local", "Ananya@123"),
    ]

    for name, username, email, password in demo_users:
        exists = conn.execute(
            "SELECT id FROM users WHERE username=?", (username,)
        ).fetchone()
        if not exists:
            conn.execute("""
                INSERT INTO users (full_name, username, email, password_hash, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (
                name, username, email, generate_password_hash(password),
                datetime.now().isoformat()
            ))
            conn.commit()

    conn.execute("UPDATE users SET is_admin=1 WHERE username='rahul_dev'")
    conn.commit()

    # Demo posts
    post_count = conn.execute("SELECT COUNT(*) AS c FROM posts").fetchone()["c"]
    if post_count == 0:
        users = conn.execute("SELECT id, username FROM users").fetchall()
        demo_images = [
            ("https://picsum.photos/seed/connect1/800/800",
             "Exploring new places and making memories #travel #life #connectx"),
            ("https://picsum.photos/seed/connect2/800/800",
             "New day. New ideas. New goals"),
            ("https://picsum.photos/seed/connect3/800/800",
             "Building something awesome #coding #developer")
        ]
        for i, image in enumerate(demo_images):
            if i < len(users):
                conn.execute("""
                    INSERT INTO posts
                    (user_id, media_url, media_type, caption, created_at)
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    users[i]["id"],
                    image[0],
                    "image",
                    image[1],
                    datetime.now().isoformat()
                ))
        conn.commit()

    conn.close()


# ============================================================
# HELPERS
# ============================================================

def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    conn = get_db()
    user = conn.execute("""
        SELECT id, full_name, username, email, bio, avatar, is_private,
               profile_music_url, profile_music_name, comments_enabled, is_verified, is_admin
        FROM users
        WHERE id=?
    """, (user_id,)).fetchone()
    conn.close()
    return user


def login_required():
    if not session.get("user_id"):
        return jsonify({
            "success": False,
            "message": "Please login first."
        }), 401
    return None


def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


def user_json(user):
    if not user:
        return None
    return {
        "id": user["id"],
        "full_name": user["full_name"],
        "username": user["username"],
        "email": user["email"],
        "bio": user["bio"],
        "avatar": user["avatar"],
        "profile_music_url": user["profile_music_url"] if "profile_music_url" in user.keys() else "",
        "profile_music_name": user["profile_music_name"] if "profile_music_name" in user.keys() else "",
        "is_private": bool(user["is_private"]),
        "is_verified": bool(user["is_verified"]) if "is_verified" in user.keys() and user["is_verified"] is not None else False,
        "is_admin": bool(user["is_admin"]) if "is_admin" in user.keys() and user["is_admin"] is not None else False,
        "comments_enabled": bool(user["comments_enabled"]) if "comments_enabled" in user.keys() and user["comments_enabled"] is not None else True
    }


# ============================================================
# FRONTEND
# ============================================================

HTML = r"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Orbit - Social Media</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
:root{
    --bg:#f5f3fa; --card:#ffffff; --text:#17171c; --muted:#777985; --border:#e5e1ed;
    --pink:#ff2d75; --orange:#ff6b35; --purple:#7c3aed; --blue:#2563eb;
    --gradient: linear-gradient(135deg, #ff2d75, #ff6b35, #8b5cf6, #2563eb);
    --shadow: 0 15px 45px rgba(40,20,80,.10);
}
body.dark{
    --bg:#000000; --card:#000000; --text:#f5f5f5; --muted:#a8a8a8; --border:#262626;
    --shadow: 0 15px 45px rgba(0,0,0,.5);
}
body{
    font-family: Arial, Helvetica, sans-serif;
    background:
        radial-gradient(circle at 10% 0%, rgba(255,45,117,.08), transparent 25%),
        radial-gradient(circle at 90% 10%, rgba(124,58,237,.10), transparent 25%),
        var(--bg);
    color:var(--text);
    transition:.3s;
}
button, input, textarea{font-family:inherit;}
#authScreen{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
.auth-box{width:100%;max-width:430px;}
.brand{text-align:center;margin-bottom:22px;}
.logo{width:76px;height:76px;border-radius:24px;background:var(--gradient);display:flex;align-items:center;justify-content:center;color:white;font-size:38px;font-weight:400;margin:auto;box-shadow:0 15px 40px rgba(124,58,237,.30);}
.brand h1{margin-top:12px;font-size:31px;}
.brand p{margin-top:6px;color:var(--muted);}
.auth-card{background:var(--card);border:1px solid var(--border);border-radius:25px;padding:28px;box-shadow:var(--shadow);}
.auth-tabs{display:flex;background:var(--bg);border-radius:13px;padding:4px;margin-bottom:22px;}
.auth-tabs button{flex:1;border:0;background:transparent;color:var(--muted);padding:12px;border-radius:10px;cursor:pointer;font-weight:bold;}
.auth-tabs button.active{background:var(--card);color:var(--text);box-shadow:0 3px 12px rgba(0,0,0,.08);}
.form-group{margin-bottom:15px;}
.form-group label{display:block;font-size:13px;font-weight:bold;margin-bottom:7px;}
.form-group input{width:100%;padding:14px;border:1px solid var(--border);border-radius:12px;outline:none;background:var(--bg);color:var(--text);}
.form-group input:focus{border-color:var(--purple);}
.password-wrap{position:relative;}
.password-wrap input{padding-right:55px;}
.show-pass{position:absolute;right:12px;top:50%;transform:translateY(-50%);border:0;background:none;color:var(--muted);cursor:pointer;}
.main-btn{width:100%;border:0;padding:14px;border-radius:13px;background:var(--gradient);color:white;font-size:15px;font-weight:bold;cursor:pointer;margin-top:5px;transition:.2s;}
.main-btn:hover{transform:translateY(-2px);box-shadow:0 10px 25px rgba(124,58,237,.25);}
.auth-note{text-align:center;color:var(--muted);font-size:12px;margin-top:18px;}
#app{display:none;}
.sidebar{position:fixed;left:0;top:0;bottom:0;width:210px;background:var(--card);border-right:1px solid var(--border);padding:20px 10px;z-index:100;}
.side-logo{display:flex;align-items:center;gap:9px;font-size:19px;font-weight:800;margin:0 10px 26px;letter-spacing:-.3px;}
.side-logo span.logo-mark{width:32px;height:32px;border-radius:9px;background:var(--gradient);color:white;display:flex;align-items:center;justify-content:center;font-size:17px;font-weight:400;}
.nav{display:flex;flex-direction:column;gap:3px;}
.nav-item{border:0;background:transparent;color:var(--text);display:flex;align-items:center;gap:13px;padding:10px 12px;border-radius:10px;cursor:pointer;font-size:14px;text-align:left;font-weight:500;}
.nav-item:hover, .nav-item.active{background:linear-gradient(90deg, rgba(124,58,237,.13), rgba(255,45,117,.09));color:var(--purple);font-weight:bold;}
.nav-icon{width:19px;text-align:center;font-size:16px;font-weight:400;opacity:.9;}
.sidebar-bottom{position:absolute;bottom:20px;left:15px;right:15px;}
.main{margin-left:210px;min-height:100vh;}
.topbar{height:64px;border-bottom:1px solid var(--border);background:rgba(255,255,255,.82);backdrop-filter:blur(15px);position:sticky;top:0;z-index:50;display:flex;align-items:center;justify-content:space-between;padding:0 26px;}
body.dark .topbar{background:rgba(24,22,32,.88);}
.search-box{background:var(--bg);border:1px solid var(--border);border-radius:12px;padding:10px 14px;width:300px;display:flex;gap:8px;position:relative;}
.search-box input{border:0;outline:0;background:transparent;color:var(--text);width:100%;}
.top-actions{display:flex;gap:10px;}
.icon-btn{width:40px;height:40px;border-radius:50%;border:1px solid var(--border);background:var(--card);color:var(--text);cursor:pointer;}
.page{display:none;max-width:1100px;margin:auto;padding:30px;}
.page.active{display:block;}
.home-layout{display:grid;grid-template-columns:minmax(0,650px) 280px;gap:30px;justify-content:center;}
.stories{display:flex;gap:17px;overflow-x:auto;padding:5px 2px 20px;}
.story{min-width:70px;text-align:center;cursor:pointer;}
.story-ring{width:66px;height:66px;border-radius:50%;padding:3px;background:var(--gradient);margin:auto;}
.story-ring img{width:100%;height:100%;object-fit:cover;border-radius:50%;border:3px solid var(--card);}
.story p{font-size:11px;margin-top:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.post{background:var(--card);border:1px solid var(--border);border-radius:18px;margin-bottom:22px;overflow:hidden;box-shadow:0 8px 30px rgba(40,20,80,.04);}
.post-head{padding:13px 15px;display:flex;align-items:center;justify-content:space-between;}
.user-info{display:flex;align-items:center;gap:10px;}
.avatar{width:40px;height:40px;border-radius:50%;background:var(--gradient);display:flex;align-items:center;justify-content:center;color:white;font-weight:bold;overflow:hidden;}
.avatar img{width:100%;height:100%;object-fit:cover;}
.user-name{font-size:14px;font-weight:bold;}
.location{color:var(--muted);font-size:11px;margin-top:2px;}
.more{border:0;background:none;color:var(--text);cursor:pointer;font-size:20px;}
.post-image{width:100%;aspect-ratio:1/1;object-fit:cover;display:block;background:var(--gradient);}
.post-video{width:100%;max-height:700px;background:#000;display:block;}
.post-actions{display:flex;align-items:center;padding:12px 15px 5px;gap:15px;}
.post-actions button{border:0;background:none;font-size:22px;cursor:pointer;color:var(--text);}
.post-actions button.liked{color:#ff245f;}
.post-actions .save{margin-left:auto;}
.post-content{padding:0 15px 16px;}
.likes{font-size:13px;font-weight:bold;margin-bottom:7px;}
.caption{font-size:14px;line-height:1.5;}
.hashtag-link, .mention-link{color:var(--purple);cursor:pointer;font-weight:600;}
.hashtag-link:hover, .mention-link:hover{text-decoration:underline;}
.comments{color:var(--muted);font-size:13px;margin-top:8px;cursor:pointer;}
.comment-box{display:flex;gap:7px;padding:0 15px 15px;}
.comment-box input{flex:1;padding:10px 12px;border:1px solid var(--border);border-radius:20px;outline:none;background:var(--bg);color:var(--text);}
.comment-box button{border:0;background:var(--gradient);color:white;border-radius:20px;padding:0 16px;cursor:pointer;}
.suggestion-box{background:var(--card);border:1px solid var(--border);border-radius:18px;padding:18px;}
.profile-mini{display:flex;align-items:center;gap:10px;margin-bottom:22px;}
.profile-mini .avatar{width:50px;height:50px;}
.suggestion-title{display:flex;justify-content:space-between;color:var(--muted);font-size:13px;margin-bottom:15px;}
.suggestion{display:flex;align-items:center;justify-content:space-between;margin:13px 0;}
.follow-btn{border:0;background:transparent;color:#3674db;font-weight:bold;cursor:pointer;}
.section-title{font-size:26px;margin-bottom:20px;}
.explore-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;}
.explore-item{aspect-ratio:1/1;overflow:hidden;cursor:pointer;}
.explore-item img, .explore-item video{width:100%;height:100%;object-fit:cover;transition:.3s;}
.explore-item:hover img{transform:scale(1.05);}
.reels-container{max-width:430px;margin:auto;}
.reel{height:650px;border-radius:20px;overflow:hidden;position:relative;margin-bottom:20px;background:#111;}
.reel img, .reel video{width:100%;height:100%;object-fit:cover;}
.reel-overlay{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:flex-end;padding:22px;color:white;background:linear-gradient(transparent 50%, rgba(0,0,0,.75));}
.reel-user{font-weight:bold;margin-bottom:8px;}
.reel-caption{font-size:14px;line-height:1.5;}
.reel-actions{position:absolute;right:14px;bottom:70px;display:flex;flex-direction:column;gap:17px;}
.reel-actions button{background:rgba(0,0,0,.35);border:0;width:43px;height:43px;border-radius:50%;color:white;cursor:pointer;font-size:20px;}
.messages{display:grid;grid-template-columns:300px 1fr;height:680px;background:var(--card);border:1px solid var(--border);border-radius:20px;overflow:hidden;box-shadow:var(--shadow);}
.chat-list{border-right:1px solid var(--border);overflow-y:auto;}
.chat-list h3{padding:20px 18px 12px;font-size:19px;}
.chat{display:flex;gap:12px;align-items:center;padding:11px 16px;cursor:pointer;transition:.15s;border-left:3px solid transparent;}
.chat:hover{background:var(--bg);}
.chat.selected{background:var(--bg);border-left-color:var(--purple);}
.chat-name{font-weight:600;font-size:13.5px;}
.chat-preview{color:var(--muted);font-size:12px;margin-top:2px;}
.chat-window{display:flex;flex-direction:column;background:var(--card);}
.chat-header{padding:14px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px;min-height:26px;}
.chat-header .avatar{width:38px;height:38px;}
.chat-messages{flex:1;padding:22px 20px;overflow-y:auto;display:flex;flex-direction:column;background:
    radial-gradient(circle at 15% 10%, rgba(124,58,237,.03), transparent 30%),
    radial-gradient(circle at 85% 90%, rgba(255,45,117,.03), transparent 30%);}
.message-row{display:flex;flex-direction:column;margin-bottom:3px;max-width:72%;}
.message-row.sent-row{align-self:flex-end;align-items:flex-end;}
.message-row.received-row{align-self:flex-start;align-items:flex-start;}
.message{padding:9px 14px;border-radius:18px;font-size:13.5px;line-height:1.4;word-wrap:break-word;overflow-wrap:break-word;white-space:pre-wrap;box-shadow:0 1px 2px rgba(0,0,0,.06);}
.message.received{background:var(--bg);border:1px solid var(--border);border-bottom-left-radius:5px;}
.message.sent{background:var(--gradient);color:white;border-bottom-right-radius:5px;}
.message-time{font-size:10px;color:var(--muted);margin:3px 6px 8px;}
.chat-input{display:flex;align-items:center;padding:13px 16px;border-top:1px solid var(--border);gap:8px;background:var(--card);}
.chat-input input{flex:1;border:1px solid var(--border);border-radius:22px;padding:11px 16px;background:var(--bg);color:var(--text);outline:none;font-size:13.5px;}
.chat-input button{border:0;border-radius:50%;width:40px;height:40px;flex-shrink:0;background:var(--gradient);color:white;cursor:pointer;font-size:16px;}
.notification{background:var(--card);border:1px solid var(--border);border-radius:15px;padding:15px;display:flex;align-items:center;gap:12px;margin-bottom:10px;}
.notification-text{flex:1;font-size:13px;}
.create-box{max-width:650px;margin:auto;background:var(--card);border:1px solid var(--border);border-radius:20px;padding:25px;}
.upload-area{min-height:300px;border:2px dashed var(--border);border-radius:17px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;margin-bottom:20px;overflow:hidden;position:relative;}
.filter-swatch{flex-shrink:0;width:56px;height:56px;border-radius:10px;overflow:hidden;cursor:pointer;border:2px solid transparent;}
.filter-swatch.active{border-color:var(--purple);}
.filter-swatch img{width:100%;height:100%;object-fit:cover;}
.preview-overlay-text{position:absolute;left:50%;bottom:14%;transform:translateX(-50%);color:white;font-weight:800;font-size:20px;text-align:center;text-shadow:0 2px 6px rgba(0,0,0,.6);max-width:90%;pointer-events:none;z-index:5;}
.carousel{position:relative;width:100%;aspect-ratio:1/1;background:#000;overflow:hidden;}
.carousel-slide{width:100%;height:100%;object-fit:cover;}
.carousel-arrow{position:absolute;top:50%;transform:translateY(-50%);border:0;background:rgba(0,0,0,.4);color:white;width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:18px;z-index:6;}
.carousel-arrow.left{left:8px;}
.carousel-arrow.right{right:8px;}
.carousel-dots{position:absolute;bottom:10px;left:0;right:0;display:flex;justify-content:center;gap:5px;z-index:6;}
.carousel-dot{width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.5);}
.carousel-dot.active{background:white;}
.carousel-count{position:absolute;top:10px;right:10px;background:rgba(0,0,0,.5);color:white;font-size:11px;padding:2px 8px;border-radius:10px;z-index:6;}
.dtl-heart{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) scale(0);font-size:70px;pointer-events:none;opacity:0;z-index:8;}
.dtl-heart.show-heart{animation:dtlPop .8s ease;}
@keyframes dtlPop{
    0%{transform:translate(-50%,-50%) scale(0);opacity:0;}
    15%{transform:translate(-50%,-50%) scale(1.15);opacity:1;}
    30%{transform:translate(-50%,-50%) scale(1);opacity:1;}
    100%{transform:translate(-50%,-50%) scale(1);opacity:0;}
}
.f-grayscale{filter:grayscale(1);}
.f-sepia{filter:sepia(.7);}
.f-warm{filter:saturate(1.4) sepia(.15) contrast(1.05);}
.f-cool{filter:saturate(1.1) hue-rotate(15deg) brightness(1.05);}
.f-contrast{filter:contrast(1.35) saturate(1.15);}
.f-fade{filter:contrast(.85) brightness(1.1) saturate(.8);}
.upload-area img, .upload-area video{width:100%;max-height:400px;object-fit:contain;}
.upload-label{padding:12px 20px;border-radius:10px;background:var(--gradient);color:white;cursor:pointer;font-weight:bold;}
#createFile{display:none;}
textarea{width:100%;min-height:100px;border:1px solid var(--border);border-radius:12px;padding:13px;resize:vertical;background:var(--bg);color:var(--text);outline:none;}
.profile-header{background:var(--card);padding:15px 0 25px;display:block;}
.profile-top-row{display:flex;align-items:center;gap:20px;margin-bottom:20px;}
.big-avatar{width:90px;height:90px;border-radius:50%;background:var(--gradient);padding:3px;flex-shrink:0;}
.big-avatar img{width:100%;height:100%;border-radius:50%;object-fit:cover;border:3px solid var(--card);}
.profile-stats-row{display:flex;flex:1;justify-content:space-around;text-align:center;}
.profile-stats-row strong{display:block;font-size:19px;}
.profile-stats-row span{color:var(--muted);font-size:13px;}
.profile-info{margin-bottom:18px;}
.profile-name{display:flex;align-items:center;gap:10px;margin-bottom:6px;}
.profile-name h2{font-size:15px;font-weight:bold;}
.edit-btn{border:1px solid var(--border);background:var(--bg);color:var(--text);padding:8px 0;border-radius:9px;cursor:pointer;flex:1;font-size:13px;font-weight:600;}
.profile-actions{display:flex;gap:8px;}
.profile-actions .edit-btn{flex:0 0 auto;padding:8px 18px;}
.bio{font-size:14px;line-height:1.5;margin-top:8px;}
.profile-tabs{display:flex;border-top:1px solid var(--border);margin-top:20px;}
.profile-tab{flex:1;text-align:center;padding:13px 0;border:0;background:none;cursor:pointer;color:var(--muted);font-size:20px;border-top:1px solid transparent;margin-top:-1px;}
.profile-tab.active{color:var(--text);border-top:1px solid var(--text);}
.profile-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;}
.profile-grid img{width:100%;aspect-ratio:1/1;object-fit:cover;}
.settings-section-label{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.5px;margin:22px 4px 8px;}
.settings-section-label:first-of-type{margin-top:0;}
.settings-card{background:var(--card);border:1px solid var(--border);border-radius:18px;overflow:hidden;}
.setting{display:flex;align-items:center;justify-content:space-between;padding:18px;border-bottom:1px solid var(--border);}
.setting:last-child{border-bottom:0;}
.setting-title{font-weight:bold;font-size:14px;}
.setting-desc{color:var(--muted);font-size:12px;margin-top:4px;}
.toggle{width:48px;height:26px;border-radius:20px;background:#ccc;position:relative;cursor:pointer;}
.toggle.active{background:var(--purple);}
.toggle::after{content:"";position:absolute;width:20px;height:20px;background:white;border-radius:50%;top:3px;left:4px;transition:.2s;}
.toggle.active::after{left:24px;}
.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.82);z-index:500;align-items:center;justify-content:center;}
.modal.show{display:flex;}
#editProfileModal .auth-card, #userListModal .auth-card{background:var(--card);border-radius:20px;padding:24px;}
.story-view{width:390px;height:680px;border-radius:20px;overflow:hidden;position:relative;background:#111;}
.story-view img{width:100%;height:100%;object-fit:cover;}
.story-user{position:absolute;top:18px;left:18px;color:white;font-weight:bold;}
.close-modal{position:absolute;top:15px;right:15px;background:rgba(0,0,0,.5);border:0;color:white;width:35px;height:35px;border-radius:50%;cursor:pointer;}
.toast{position:fixed;right:25px;bottom:25px;background:#17171c;color:white;padding:13px 18px;border-radius:12px;opacity:0;transform:translateY(20px);pointer-events:none;transition:.3s;z-index:1000;}
.toast.show{opacity:1;transform:translateY(0);}
.mobile-top{display:none;}
.bottom-nav{display:none;}
@media(max-width:900px){
    .sidebar{display:none;}
    .main{margin-left:0;padding-bottom:70px;}
    .mobile-top{display:flex;height:60px;align-items:center;justify-content:space-between;padding:0 15px;background:var(--card);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:100;}
    .mobile-brand{font-size:22px;font-weight:900;background:var(--gradient);-webkit-background-clip:text;color:transparent;}
    .topbar{display:none;}
    .home-layout{grid-template-columns:1fr;}
    .right-side{display:none;}
    .bottom-nav{display:flex;position:fixed;bottom:0;left:0;right:0;height:65px;background:var(--card);border-top:1px solid var(--border);z-index:200;justify-content:space-around;align-items:center;}
    .bottom-nav button{background:none;border:0;color:var(--text);font-size:22px;cursor:pointer;}
    .page{padding:20px 14px;}
    .messages{grid-template-columns:1fr;height:600px;}
    .chat-list{display:none;}
    .profile-header{padding:20px;}
    .big-avatar{width:100px;height:100px;}
}
@media(max-width:600px){
    .auth-card{padding:20px;}
    .page{padding:14px 8px;}
    .stories{padding-left:5px;}
    .post{border-radius:10px;border-left:0;border-right:0;}
    .explore-grid{grid-template-columns:repeat(3,1fr);}
    .big-avatar{width:76px;height:76px;}
    .story-view{width:100%;height:100%;border-radius:0;}
    .reel{height:calc(100vh - 100px);border-radius:10px;}
}
</style>
</head>
<body>

<section id="authScreen">
<div class="auth-box">
<div class="brand">
<div class="logo">◎</div>
<h1>Orbit</h1>
<p>Share moments. Connect people.</p>
</div>
<div class="auth-card">
<div class="auth-tabs">
<button id="loginTab" class="active" onclick="showLogin()">Login</button>
<button id="signupTab" onclick="showSignup()">Create account</button>
</div>

<form id="loginForm" onsubmit="login(event)">
<div class="form-group">
<label>Email or Username</label>
<input id="loginUser" type="text" placeholder="Enter username or email" required>
</div>
<div class="form-group">
<label>Password</label>
<div class="password-wrap">
<input id="loginPassword" type="password" placeholder="Enter password" required>
<button type="button" class="show-pass" onclick="togglePassword('loginPassword')">👁</button>
</div>
</div>
<button class="main-btn" type="submit">Login</button>
<div style="text-align:center;margin-top:14px">
<span style="color:var(--purple);font-size:13px;cursor:pointer" onclick="openForgotPassword()">Forgot password?</span>
</div>
</form>

<form id="signupForm" style="display:none" onsubmit="signup(event)">
<div class="form-group">
<label>Full Name</label>
<input id="signupName" type="text" placeholder="Your full name" required>
</div>
<div class="form-group">
<label>Username</label>
<input id="signupUsername" type="text" placeholder="username" required>
</div>
<div class="form-group">
<label>Email</label>
<input id="signupEmail" type="email" placeholder="you@example.com" required>
</div>
<div class="form-group">
<label>Password</label>
<div class="password-wrap">
<input id="signupPassword" type="password" placeholder="Create password" required>
<button type="button" class="show-pass" onclick="togglePassword('signupPassword')">👁</button>
</div>
</div>
<button class="main-btn" type="submit">Create Account</button>
</form>

<div class="auth-note">Your account is stored securely in the Orbit database.</div>
</div>
</div>
</section>

<div class="modal" id="forgotPasswordModal">
<div class="auth-card" style="width:360px;position:relative">
<button class="close-modal" style="position:absolute;top:10px;right:10px;background:var(--bg);color:var(--text)" onclick="closeForgotPassword()">✕</button>
<h3 style="margin-bottom:16px">Reset password</h3>
<div id="forgotStep1">
<div class="form-group">
<label>Username or email</label>
<input id="forgotIdentity" type="text" placeholder="Enter username or email">
</div>
<button class="main-btn" onclick="requestResetCode()">Send reset code</button>
</div>
<div id="forgotStep2" style="display:none">
<div id="forgotDemoNote" style="background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:10px;font-size:12px;color:var(--muted);margin-bottom:14px"></div>
<div class="form-group">
<label>Reset code</label>
<input id="resetCodeInput" type="text" maxlength="8" placeholder="8-character code">
</div>
<div class="form-group">
<label>New password</label>
<input id="resetNewPassword" type="password" placeholder="At least 6 characters">
</div>
<button class="main-btn" onclick="submitPasswordReset()">Reset password</button>
</div>
</div>
</div>

<div id="app">
<aside class="sidebar">
<div class="side-logo"><span class="logo-mark">◎</span>Orbit</div>
<nav class="nav">
<button class="nav-item active" onclick="showPage('home',this)"><span class="nav-icon">🏠</span>Home</button>
<button class="nav-item" onclick="showPage('explore',this)"><span class="nav-icon">🔍</span>Explore</button>
<button class="nav-item" onclick="showPage('reels',this)"><span class="nav-icon">🎬</span>Reels</button>
<button class="nav-item" onclick="showPage('messages',this)"><span class="nav-icon">💬</span>Messages</button>
<button class="nav-item" onclick="showPage('notifications',this)"><span class="nav-icon">❤️</span>Notifications<span id="notifBadgeSidebar" style="display:none;background:#ff2d75;color:white;font-size:10px;border-radius:10px;padding:1px 6px;margin-left:auto"></span></button>
<button class="nav-item" onclick="showPage('create',this)"><span class="nav-icon">➕</span>Create</button>
<button class="nav-item" onclick="goToMyProfile(this)"><span class="nav-icon">👤</span>Profile</button>
</nav>
</aside>

<div class="mobile-top">
<div class="mobile-brand">Orbit</div>
<div>
<button class="icon-btn" onclick="showPage('notifications')">❤️</button>
</div>
</div>

<header class="topbar">
<div class="search-box">🔍<input id="globalSearch" type="text" placeholder="Search Orbit..." oninput="searchUsers()"></div>
<div class="top-actions">
<button class="icon-btn" onclick="showPage('messages')">💬</button>
<button class="icon-btn" style="position:relative" onclick="showPage('notifications')">🔔<span id="notifBadgeTop" style="display:none;position:absolute;top:-2px;right:-2px;background:#ff2d75;color:white;font-size:9px;border-radius:8px;padding:1px 5px"></span></button>
<button class="icon-btn" onclick="goToMyProfile()">👤</button>
</div>
</header>

<main id="home" class="page active">
<div class="home-layout">
<div>
<div class="stories" id="stories"></div>
<div id="feed"></div>
</div>
<aside class="right-side">
<div class="suggestion-box">
<div class="profile-mini" id="miniProfile"></div>
<div class="suggestion-title"><b>Suggested for you</b><span>See all</span></div>
<div id="suggestions"></div>
</div>
</aside>
</div>
</main>

<section id="explore" class="page">
<h2 class="section-title">Explore</h2>
<div class="search-box" style="width:100%;max-width:400px;margin-bottom:16px;position:relative">
🔍
<input id="exploreSearch" type="text" placeholder="Search by username or #hashtag..." oninput="searchExplore()" onfocus="if(!this.value)showRecentSearches()">
</div>
<div class="auth-tabs" style="max-width:260px;margin-bottom:16px">
<button id="exploreTabAll" class="active" onclick="setExploreTab('all')">For You</button>
<button id="exploreTabTrending" onclick="setExploreTab('trending')">🔥 Trending</button>
</div>
<div id="exploreUserResults"></div>
<div class="explore-grid" id="exploreGrid"></div>
</section>

<section id="reels" class="page">
<h2 class="section-title">Reels</h2>
<div class="reels-container" id="reelsContainer"></div>
</section>

<section id="messages" class="page">
<h2 class="section-title">Messages</h2>
<div class="messages">
<div class="chat-list">
<h3>Chats</h3>
<div id="chatList"></div>
</div>
<div class="chat-window">
<div class="chat-header" id="chatHeader">
<div style="display:flex;align-items:center;gap:12px;color:var(--muted)">
<span style="font-size:22px">💬</span>
<b>Select a chat to start messaging</b>
</div>
</div>
<div class="chat-messages" id="chatMessages"></div>
<div id="emojiPicker" style="display:none;padding:10px;border-top:1px solid var(--border);flex-wrap:wrap;gap:6px;max-height:120px;overflow:auto;background:var(--card)"></div>
<div class="chat-input">
<button type="button" class="icon-btn" style="width:38px;height:38px;flex-shrink:0" onclick="toggleEmojiPicker()">😊</button>
<label class="icon-btn" style="width:38px;height:38px;flex-shrink:0;display:flex;align-items:center;justify-content:center;cursor:pointer" for="chatImageInput">📷</label>
<input id="chatImageInput" type="file" accept="image/*" style="display:none" onchange="sendChatImage(event)">
<input id="messageInput" placeholder="Message...">
<button onclick="sendMessage()">➤</button>
</div>
</div>
</div>
</section>

<section id="notifications" class="page">
<h2 class="section-title">Notifications</h2>
<div class="auth-tabs" style="max-width:260px;margin-bottom:16px">
<button id="notifTabYou" class="active" onclick="setNotifTab('you')">You</button>
<button id="notifTabFollowing" onclick="setNotifTab('following')">Following</button>
</div>
<div id="notificationList"></div>
</section>

<section id="create" class="page">
<h2 class="section-title">Create New</h2>
<div class="create-box">
<div class="auth-tabs" style="margin-bottom:20px">
<button id="createPostTab" class="active" onclick="setCreateMode('post')">Post</button>
<button id="createReelTab" onclick="setCreateMode('reel')">Reel</button>
<button id="createStoryTab" onclick="setCreateMode('story')">Story</button>
</div>
<div class="upload-area" id="uploadArea" ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)" ondrop="handleDrop(event)">
<div style="font-size:45px">📸</div>
<b>Select a photo or video</b>
<div style="font-size:12px;color:var(--muted)">or drag and drop it here</div>
<label class="upload-label" for="createFile">Choose from device</label>
<input id="createFile" type="file" accept="image/*,video/*" onchange="previewMedia(event)">
</div>
<textarea id="captionInput" placeholder="Write a caption..."></textarea>

<div class="form-group" style="margin-top:15px">
<label>📍 Add location (optional)</label>
<input id="locationInput" type="text" maxlength="60" placeholder="e.g. Mumbai, India">
</div>

<div class="form-group" style="margin-top:15px">
<label>🎨 Filter</label>
<div id="filterRow" style="display:flex;gap:8px;overflow-x:auto;padding:8px 0"></div>
</div>

<div class="form-group">
<label>🔤 Text overlay on image (optional)</label>
<input id="overlayTextInput" type="text" maxlength="60" placeholder="e.g. Good vibes only" oninput="updatePreviewOverlay()">
</div>

<div class="form-group" style="margin-top:15px">
<label>🎵 Add music (optional)</label>
<input id="musicFile" type="file" accept="audio/*" onchange="previewMusic(event)">
<div id="musicPreview" style="margin-top:8px;font-size:13px;color:var(--muted)"></div>
</div>
<br>
<div id="uploadProgressBar" style="display:none;height:6px;background:var(--border);border-radius:4px;overflow:hidden;margin-bottom:12px">
<div id="uploadProgressFill" style="height:100%;width:0%;background:var(--gradient);transition:.2s"></div>
</div>
<button class="main-btn" id="publishBtn" onclick="publishPost()">Share Post</button>
</div>
</section>

<section id="profile" class="page">
<div class="profile-header" id="profileHeader"></div>
<div class="profile-grid" id="profileGrid"></div>
</section>

<div class="modal" id="profileMenuModal">
<div class="auth-card" style="width:320px;position:relative;padding:0;overflow:hidden">
<button class="close-modal" style="position:absolute;top:10px;right:10px;background:var(--bg);color:var(--text);z-index:5" onclick="closeProfileMenu()">✕</button>
<div class="settings-card" style="border:0;border-radius:0">
<div class="setting">
<div>
<div class="setting-title">Dark Mode</div>
<div class="setting-desc">Change app appearance</div>
</div>
<div class="toggle" id="profileMenuDarkToggle" onclick="toggleDarkMode()"></div>
</div>
<div class="setting" style="cursor:pointer" onclick="closeProfileMenu();showPage('settings');initSettingsPage()">
<div>
<div class="setting-title">Settings</div>
<div class="setting-desc">Privacy, security and more</div>
</div>
<span style="font-size:18px">›</span>
</div>
<div class="setting" style="cursor:pointer" onclick="logout()">
<div>
<div class="setting-title" style="color:#ff2d75">Logout</div>
<div class="setting-desc">Sign out of this device</div>
</div>
<span style="font-size:18px">🚪</span>
</div>
</div>
</div>
</div>

<div class="modal" id="editProfileModal">
<div class="auth-card" style="width:400px;position:relative">
<button class="close-modal" style="position:absolute;top:10px;right:10px;background:var(--bg);color:var(--text)" onclick="closeEditProfile()">✕</button>
<h3 style="margin-bottom:18px">Edit profile</h3>
<div class="form-group" style="text-align:center">
<label class="upload-label" for="avatarFile" style="display:inline-block">Change photo</label>
<input id="avatarFile" type="file" accept="image/*" style="display:none" onchange="uploadAvatar(event)">
</div>
<div class="form-group">
<label>🎵 Profile music</label>
<label class="upload-label" for="profileMusicFile" style="display:inline-block">Add / change music</label>
<input id="profileMusicFile" type="file" accept="audio/*" style="display:none" onchange="uploadProfileMusic(event)">
<button type="button" class="edit-btn" style="margin-left:8px" onclick="removeProfileMusic()">Remove</button>
</div>
<div class="form-group">
<label>Full Name</label>
<input id="editFullName" type="text">
</div>
<div class="form-group">
<label>Bio</label>
<textarea id="editBio" style="min-height:70px"></textarea>
</div>
<button class="main-btn" onclick="saveProfileEdit()">Save changes</button>
</div>
</div>

<div class="modal" id="userListModal">
<div class="auth-card" style="width:380px;max-height:70vh;overflow:auto;position:relative">
<button class="close-modal" style="position:absolute;top:10px;right:10px;background:var(--bg);color:var(--text)" onclick="closeUserListModal()">✕</button>
<h3 id="userListTitle" style="margin-bottom:15px">Users</h3>
<div id="userListBody"></div>
</div>
</div>

<div class="modal" id="postLightbox">
<div style="width:min(500px,92vw);max-height:88vh;overflow:auto;background:var(--card);border-radius:18px;position:relative">
<button class="close-modal" style="position:absolute;top:10px;right:10px;background:rgba(0,0,0,.5);z-index:10" onclick="closeLightbox()">✕</button>
<div id="lightboxBody"></div>
</div>
</div>

<div class="modal" id="postOptionsModal">
<div class="auth-card" style="width:300px">
<div id="postOptionsBody"></div>
</div>
</div>

<div class="modal" id="editPostModal">
<div class="auth-card" style="width:400px;position:relative">
<button class="close-modal" style="position:absolute;top:10px;right:10px;background:var(--bg);color:var(--text)" onclick="closeEditPost()">✕</button>
<h3 style="margin-bottom:18px">Edit post</h3>
<div class="form-group">
<label>Caption</label>
<textarea id="editPostCaption" style="min-height:80px"></textarea>
</div>
<div class="form-group">
<label>Text overlay on image</label>
<input id="editPostOverlay" type="text" maxlength="60">
</div>
<button class="main-btn" onclick="saveEditPost()">Save changes</button>
</div>
</div>

<div class="modal" id="callModal">
<div style="width:min(500px,94vw);background:#111;border-radius:18px;overflow:hidden;position:relative">
<div style="position:relative;background:#000;aspect-ratio:4/3">
<video id="remoteVideo" autoplay playsinline style="width:100%;height:100%;object-fit:cover;background:#222"></video>
<video id="localVideo" autoplay playsinline muted style="position:absolute;bottom:12px;right:12px;width:110px;border-radius:10px;border:2px solid white;object-fit:cover"></video>
<div id="callStatusText" style="position:absolute;top:12px;left:12px;color:white;font-size:13px;background:rgba(0,0,0,.4);padding:4px 10px;border-radius:8px">Calling...</div>
</div>
<div style="display:flex;justify-content:center;gap:16px;padding:16px;background:#111">
<button onclick="endCall()" style="width:52px;height:52px;border-radius:50%;border:0;background:#ff2d2d;color:white;font-size:20px;cursor:pointer">✕</button>
</div>
</div>
</div>

<div class="modal" id="incomingCallModal">
<div class="auth-card" style="width:320px;text-align:center">
<div style="font-size:40px;margin-bottom:10px">📹</div>
<h3 id="incomingCallText" style="margin-bottom:20px">Incoming video call...</h3>
<div style="display:flex;gap:12px;justify-content:center">
<button class="main-btn" style="background:#2ecc71;flex:1" onclick="acceptIncomingCall()">Accept</button>
<button class="main-btn" style="background:#ff2d2d;flex:1" onclick="declineIncomingCall()">Decline</button>
</div>
</div>
</div>

<section id="settings" class="page">
<h2 class="section-title">Settings and activity</h2>

<div class="settings-section-label">Who can see your content</div>
<div class="settings-card">
<div class="setting" style="cursor:pointer" onclick="togglePrivate()">
<div><div class="setting-title">Account privacy</div><div class="setting-desc" id="privacyStatusText">Public</div></div>
<div class="toggle" id="privateToggle" onclick="event.stopPropagation();togglePrivate()"></div>
</div>
<div class="setting" style="cursor:pointer" onclick="openCloseFriends()">
<div><div class="setting-title">Close Friends</div><div class="setting-desc">Share with a select group</div></div>
<span style="font-size:18px">›</span>
</div>
<div class="setting" style="cursor:pointer" onclick="openBlockedList()">
<div><div class="setting-title">Blocked accounts</div><div class="setting-desc">Manage blocked users</div></div>
<span style="font-size:18px">›</span>
</div>
<div class="setting" style="cursor:pointer" onclick="openMutedList()">
<div><div class="setting-title">Muted accounts</div><div class="setting-desc">Hide their posts from your feed</div></div>
<span style="font-size:18px">›</span>
</div>
</div>

<div class="settings-section-label">How others can interact with you</div>
<div class="settings-card">
<div class="setting">
<div><div class="setting-title">Comments</div><div class="setting-desc">Allow comments on your posts</div></div>
<div class="toggle" id="commentsToggle" onclick="toggleCommentsSetting()"></div>
</div>
</div>

<div class="settings-section-label">How you use the app</div>
<div class="settings-card">
<div class="setting" style="cursor:pointer" onclick="openSavedPosts()">
<div><div class="setting-title">Saved</div><div class="setting-desc">Posts you've saved</div></div>
<span style="font-size:18px">›</span>
</div>
<div class="setting">
<div><div class="setting-title">Dark Mode</div><div class="setting-desc">Change app appearance</div></div>
<div class="toggle" id="darkToggle" onclick="toggleDarkMode()"></div>
</div>
<div class="setting" style="cursor:pointer" onclick="showPage('notifications')">
<div><div class="setting-title">Notifications</div><div class="setting-desc">Likes, comments and followers</div></div>
<span style="font-size:18px">›</span>
</div>
</div>

<div class="settings-section-label">More info and support</div>
<div class="settings-card">
<div class="setting" style="cursor:pointer" onclick="showToast('Your account uses secure password hashing.')">
<div><div class="setting-title">Security</div><div class="setting-desc">Password and account security</div></div>
<span style="font-size:18px">›</span>
</div>
<div class="setting" style="cursor:pointer" onclick="showToast('Orbit — a demo social app.')">
<div><div class="setting-title">About</div><div class="setting-desc">App info</div></div>
<span style="font-size:18px">›</span>
</div>
</div>

<div class="settings-section-label" id="adminSectionLabel" style="display:none">Admin</div>
<div class="settings-card" id="adminSectionCard" style="display:none">
<div class="setting" style="cursor:pointer" onclick="showPage('admin');loadAdminPanel()">
<div><div class="setting-title">Admin panel</div><div class="setting-desc">Reports and app stats</div></div>
<span style="font-size:18px">›</span>
</div>
</div>

<div class="settings-section-label">Login</div>
<div class="settings-card">
<div class="setting" style="cursor:pointer" onclick="logout()">
<div><div class="setting-title" style="color:#ff2d75">Logout</div><div class="setting-desc">Sign out of this device</div></div>
<span style="font-size:18px">🚪</span>
</div>
</div>

</section>

</div>

<div class="bottom-nav">
<button onclick="showPage('home')">🏠</button>
<button onclick="showPage('explore')">🔍</button>
<button onclick="showPage('create')">➕</button>
<button onclick="showPage('reels')">🎬</button>
<button onclick="goToMyProfile()">👤</button>
</div>

<div class="modal" id="storyModal">
<div class="story-view">
<img id="storyImage" src="https://picsum.photos/seed/story/700/1200">
<div class="story-user" id="storyUser">@user</div>
<div id="storyMusicBox"></div>
<button class="close-modal" onclick="closeStory()">✕</button>
<button onclick="prevStory()" style="position:absolute;left:0;top:0;bottom:0;width:30%;border:0;background:none;cursor:pointer"></button>
<button onclick="nextStory()" style="position:absolute;right:0;top:0;bottom:0;width:30%;border:0;background:none;cursor:pointer"></button>
</div>
</div>

<div class="toast" id="toast"></div>

<script>
let currentUser = null;
let selectedFile = null;
let selectedFiles = [];
let selectedMusic = null;

function previewMusic(event){
    const file = event.target.files[0];
    selectedMusic = file || null;
    const box = document.getElementById("musicPreview");
    box.textContent = file ? ("Selected: " + file.name) : "";
}
let selectedChatUser = null;
let toastTimer;

async function api(url, options = {}){
    try{
        const response = await fetch(url, { credentials:"same-origin", ...options });
        const data = await response.json();
        if(!response.ok){
            throw new Error(data.message || "Something went wrong");
        }
        return data;
    }catch(error){
        showToast(error.message);
        throw error;
    }
}

function showLogin(){
    document.getElementById("loginForm").style.display="block";
    document.getElementById("signupForm").style.display="none";
    document.getElementById("loginTab").classList.add("active");
    document.getElementById("signupTab").classList.remove("active");
}

function showSignup(){
    document.getElementById("loginForm").style.display="none";
    document.getElementById("signupForm").style.display="block";
    document.getElementById("loginTab").classList.remove("active");
    document.getElementById("signupTab").classList.add("active");
}

function togglePassword(id){
    const input = document.getElementById(id);
    input.type = input.type === "password" ? "text" : "password";
}

function openForgotPassword(){
    document.getElementById("forgotIdentity").value = "";
    document.getElementById("resetCodeInput").value = "";
    document.getElementById("resetNewPassword").value = "";
    document.getElementById("forgotStep1").style.display = "block";
    document.getElementById("forgotStep2").style.display = "none";
    document.getElementById("forgotPasswordModal").classList.add("show");
}

function closeForgotPassword(){
    document.getElementById("forgotPasswordModal").classList.remove("show");
}

async function requestResetCode(){
    const identity = document.getElementById("forgotIdentity").value.trim();
    if(!identity){
        showToast("Enter your username or email");
        return;
    }
    try{
        const data = await fetch("/api/auth/forgot", {
            method:"POST",
            headers:{ "Content-Type":"application/json" },
            credentials:"same-origin",
            body:JSON.stringify({ email: identity })
        }).then(r=>r.json());

        if(!data.success){
            showToast(data.message || "Something went wrong");
            return;
        }

        document.getElementById("forgotDemoNote").innerHTML =
            `This is a demo app with no real email server. Your reset code is:<br><b style="font-size:16px;color:var(--purple)">${data.demo_token}</b><br>In a real app this would be emailed to you instead.`;
        document.getElementById("forgotStep1").style.display = "none";
        document.getElementById("forgotStep2").style.display = "block";
    }catch(e){
        showToast("Something went wrong");
    }
}

async function submitPasswordReset(){
    const token = document.getElementById("resetCodeInput").value.trim();
    const password = document.getElementById("resetNewPassword").value;
    if(!token || password.length < 6){
        showToast("Enter the code and a password of at least 6 characters");
        return;
    }
    try{
        const data = await fetch("/api/auth/reset", {
            method:"POST",
            headers:{ "Content-Type":"application/json" },
            credentials:"same-origin",
            body:JSON.stringify({ token, password })
        }).then(r=>r.json());

        if(!data.success){
            showToast(data.message || "Something went wrong");
            return;
        }

        showToast("Password reset. You can log in now.");
        closeForgotPassword();
    }catch(e){
        showToast("Something went wrong");
    }
}

async function login(event){
    event.preventDefault();
    const username = document.getElementById("loginUser").value.trim();
    const password = document.getElementById("loginPassword").value;
    if(!username || !password){
        showToast("Enter username/email and password");
        return;
    }
    try{
        const data = await api("/api/login", {
            method:"POST",
            headers:{ "Content-Type":"application/json" },
            body:JSON.stringify({ username, password })
        });
        currentUser = data.user;
        openApp();
        await loadApp();
        showToast("Welcome " + currentUser.username);
    }catch(e){}
}

async function signup(event){
    event.preventDefault();
    const full_name = document.getElementById("signupName").value.trim();
    const username = document.getElementById("signupUsername").value.trim().replace(/^@/,"");
    const email = document.getElementById("signupEmail").value.trim();
    const password = document.getElementById("signupPassword").value;
    if(password.length < 6){
        showToast("Password must be at least 6 characters");
        return;
    }
    try{
        const data = await api("/api/register", {
            method:"POST",
            headers:{ "Content-Type":"application/json" },
            body:JSON.stringify({ full_name, username, email, password })
        });
        currentUser = data.user;
        openApp();
        await loadApp();
        showToast("Account created successfully");
    }catch(e){}
}

function openApp(){
    document.getElementById("authScreen").style.display="none";
    document.getElementById("app").style.display="block";
}

function closeApp(){
    document.getElementById("app").style.display="none";
    document.getElementById("authScreen").style.display="flex";
}

async function logout(){
    try{ await api("/api/logout", { method:"POST" }); }catch(e){}
    stopSignalPolling();
    stopNotifBadgePolling();
    stopChatAutoRefresh();
    closeCallUI();
    currentUser=null;
    closeApp();
    showLogin();
    showToast("Logged out");
}

async function loadApp(){
    try{
        const me = await api("/api/me");
        currentUser = me.user;
        await Promise.all([
            loadFeed(), loadSuggestions(), loadStories(),
            loadExplore(), loadProfile(), loadChats(), loadNotifications(), loadReels()
        ]);
        updateMiniProfile();
        startSignalPolling();
        startNotifBadgePolling();
    }catch(e){
        closeApp();
    }
}

let notifBadgeTimer = null;

function startNotifBadgePolling(){
    stopNotifBadgePolling();
    updateNotifBadge();
    notifBadgeTimer = setInterval(updateNotifBadge, 15000);
}

function stopNotifBadgePolling(){
    if(notifBadgeTimer){ clearInterval(notifBadgeTimer); notifBadgeTimer = null; }
}

async function updateNotifBadge(){
    try{
        const data = await api("/api/notifications/unread-count");
        const badges = [document.getElementById("notifBadgeSidebar"), document.getElementById("notifBadgeTop")];
        badges.forEach(b=>{
            if(!b) return;
            if(data.count > 0){
                b.textContent = data.count > 9 ? "9+" : String(data.count);
                b.style.display = "inline-block";
            }else{
                b.style.display = "none";
            }
        });
    }catch(e){}
}

function showPage(pageId, element){
    document.querySelectorAll(".page").forEach(page=>{ page.classList.remove("active"); });
    const page = document.getElementById(pageId);
    if(page){ page.classList.add("active"); }
    document.querySelectorAll(".nav-item").forEach(item=>{ item.classList.remove("active"); });
    if(element){ element.classList.add("active"); }
    window.scrollTo({ top:0, behavior:"smooth" });
}

async function loadFeed(){
    const data = await api("/api/posts");
    window.__feedPostsCache = {};
    data.posts.forEach(p=>{ window.__feedPostsCache[p.id] = p; });
    const feed = document.getElementById("feed");
    feed.innerHTML="";
    data.posts.forEach(post=>{
        const article = document.createElement("article");
        article.className="post";
        const avatar = post.avatar || `https://i.pravatar.cc/100?u=${post.username}`;
        const filterClass = post.filter_name ? "f-" + post.filter_name : "";
        const allMedia = (post.media_items && post.media_items.length > 1)
            ? post.media_items
            : [{ media_url: post.media_url, media_type: post.media_type }];

        let media = "";
        if(allMedia.length > 1){
            const slides = allMedia.map((m, i)=>
                m.media_type === "video"
                    ? `<video class="carousel-slide ${filterClass}" src="${m.media_url}" controls style="display:${i===0?'block':'none'}" data-idx="${i}"></video>`
                    : `<img class="carousel-slide ${filterClass}" src="${m.media_url}" style="display:${i===0?'block':'none'}" data-idx="${i}">`
            ).join("");
            const dots = allMedia.map((_, i)=>`<span class="carousel-dot ${i===0?'active':''}" data-idx="${i}"></span>`).join("");
            media = `
                <div class="carousel" data-post="${post.id}">
                    ${slides}
                    <button class="carousel-arrow left" onclick="carouselNav(${post.id}, -1)">‹</button>
                    <button class="carousel-arrow right" onclick="carouselNav(${post.id}, 1)">›</button>
                    <div class="carousel-dots">${dots}</div>
                    <div class="carousel-count">1/${allMedia.length}</div>
                </div>
            `;
        }else if(post.media_type === "video"){
            media = `<video class="post-video ${filterClass}" src="${post.media_url}" controls></video>`;
        }else{
            media = `<img class="post-image ${filterClass}" src="${post.media_url}">`;
        }
        const overlayHtml = post.overlay_text
            ? `<div class="preview-overlay-text">${escapeHtml(post.overlay_text)}</div>`
            : "";
        const mediaBlock = `<div style="position:relative" ondblclick="doubleTapLike(${post.id}, this)">${media}${overlayHtml}<div class="dtl-heart">❤️</div></div>`;
        const liked = post.liked ? "liked" : "";
        const likeIcon = post.liked ? "♥" : "♡";
        const musicHtml = post.music_url ? `
            <div style="display:flex;align-items:center;gap:8px;padding:8px 15px;background:var(--bg);margin:0 15px 10px;border-radius:10px">
                <span>🎵</span>
                <span style="font-size:12px;flex:1">${escapeHtml(post.music_name || "Music")}</span>
                <audio controls style="height:30px;max-width:160px" src="${post.music_url}"></audio>
            </div>
        ` : "";
        article.innerHTML = `
        <div class="post-head">
            <div class="user-info" style="cursor:pointer" onclick="viewUserProfile('${post.username}')">
                <div class="avatar"><img src="${avatar}"></div>
                <div>
                    <div class="user-name">${escapeHtml(post.username)}${verifiedBadge(post.is_verified)}</div>
                    <div class="location">${post.location ? escapeHtml(post.location) : "Orbit"}</div>
                </div>
            </div>
            <button class="more" onclick="openPostOptions(${post.id}, ${Number(post.user_id) === Number(currentUser.id)})">•••</button>
        </div>
        ${mediaBlock}
        ${musicHtml}
        <div class="post-actions">
            <button class="${liked}" onclick="likePost(${post.id},this)">${likeIcon}</button>
            <button onclick="focusComment(${post.id})">💬</button>
            <button onclick="sharePost(${post.id})">➤</button>
            <button class="save" onclick="savePost(${post.id},this)">${post.saved ? "♣" : "♧"}</button>
        </div>
        <div class="post-content">
            <div class="likes">${post.likes} ${post.likes === 1 ? "like" : "likes"}</div>
            <div class="caption"><b>${escapeHtml(post.username)}</b> ${formatCaptionHtml(post.caption)}</div>
            <div class="comments" onclick="focusComment(${post.id})">View ${post.comments_count} comments</div>
        </div>
        <div class="comment-box">
            <input id="comment-${post.id}" placeholder="Add a comment...">
            <button onclick="addComment(${post.id})">Post</button>
        </div>
        `;
        feed.appendChild(article);
    });
}

let postOptionsTargetId = null;

function openPostOptions(postId, isOwner){
    postOptionsTargetId = postId;
    const box = document.getElementById("postOptionsBody");
    box.innerHTML = "";
    if(isOwner){
        const edit = document.createElement("button");
        edit.className = "edit-btn";
        edit.style.cssText = "width:100%;margin-bottom:8px";
        edit.textContent = "Edit post";
        edit.onclick = openEditPost;
        box.appendChild(edit);

        const del = document.createElement("button");
        del.className = "edit-btn";
        del.style.cssText = "width:100%;color:#ff2d75;margin-bottom:8px";
        del.textContent = "Delete post";
        del.onclick = confirmDeletePost;
        box.appendChild(del);
    }else{
        const report = document.createElement("button");
        report.className = "edit-btn";
        report.style.cssText = "width:100%;color:#ff2d75;margin-bottom:8px";
        report.textContent = "Report post";
        report.onclick = ()=>{ closePostOptions(); promptReportPost(postId); };
        box.appendChild(report);
    }
    const cancel = document.createElement("button");
    cancel.className = "edit-btn";
    cancel.style.width = "100%";
    cancel.textContent = "Cancel";
    cancel.onclick = closePostOptions;
    box.appendChild(cancel);
    document.getElementById("postOptionsModal").classList.add("show");
}

function promptReportPost(postId){
    const reason = prompt("Why are you reporting this post?");
    if(!reason || !reason.trim()) return;
    api("/api/report", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body:JSON.stringify({ target_type:"post", target_id:postId, reason: reason.trim() })
    }).then(()=>{ showToast("Report submitted. Thanks for letting us know."); }).catch(()=>{});
}

function openEditPost(){
    const post = (window.__feedPostsCache || {})[postOptionsTargetId];
    closePostOptions();
    document.getElementById("editPostCaption").value = post ? (post.caption || "") : "";
    document.getElementById("editPostOverlay").value = post ? (post.overlay_text || "") : "";
    document.getElementById("editPostModal").classList.add("show");
}

function closeEditPost(){
    document.getElementById("editPostModal").classList.remove("show");
}

async function saveEditPost(){
    const caption = document.getElementById("editPostCaption").value.trim();
    const overlay_text = document.getElementById("editPostOverlay").value.trim();
    try{
        await api(`/api/posts/${postOptionsTargetId}`, {
            method:"PUT",
            headers:{ "Content-Type":"application/json" },
            body:JSON.stringify({ caption, overlay_text })
        });
        closeEditPost();
        await loadFeed();
        await loadExplore();
        showToast("Post updated");
    }catch(e){}
}

function closePostOptions(){
    document.getElementById("postOptionsModal").classList.remove("show");
    postOptionsTargetId = null;
}

async function confirmDeletePost(){
    if(!postOptionsTargetId) return;
    try{
        await api(`/api/posts/${postOptionsTargetId}`, { method:"DELETE" });
        closePostOptions();
        await loadFeed();
        await loadExplore();
        await loadProfile();
        showToast("Post deleted");
    }catch(e){}
}

function carouselNav(postId, direction){
    const container = document.querySelector(`.carousel[data-post="${postId}"]`);
    if(!container) return;
    const slides = container.querySelectorAll(".carousel-slide");
    const dots = container.querySelectorAll(".carousel-dot");
    let current = 0;
    slides.forEach((s, i)=>{ if(s.style.display !== "none") current = i; });
    let next = current + direction;
    if(next < 0) next = 0;
    if(next >= slides.length) next = slides.length - 1;
    slides.forEach((s, i)=>{ s.style.display = i === next ? "block" : "none"; });
    dots.forEach((d, i)=>{ d.classList.toggle("active", i === next); });
    container.querySelector(".carousel-count").textContent = `${next+1}/${slides.length}`;
}

async function doubleTapLike(postId, wrapperEl){
    const heart = wrapperEl.querySelector(".dtl-heart");
    heart.classList.remove("show-heart");
    void heart.offsetWidth;
    heart.classList.add("show-heart");

    const post = (window.__feedPostsCache || {})[postId];
    if(post && post.liked) return;

    try{
        await api(`/api/posts/${postId}/like`, { method:"POST" });
        await loadFeed();
    }catch(e){}
}

async function likePost(postId, button){
    try{
        const data = await api(`/api/posts/${postId}/like`, { method:"POST" });
        button.classList.toggle("liked", data.liked);
        button.innerHTML = data.liked ? "♥" : "♡";
        await loadFeed();
        if(document.getElementById("reels").classList.contains("active")){
            await loadReels();
        }
    }catch(e){}
}

async function savePost(postId, button){
    try{
        const data = await api(`/api/posts/${postId}/save`, { method:"POST" });
        button.innerHTML = data.saved ? "♣" : "♧";
        showToast(data.saved ? "Post saved" : "Removed from saved");
    }catch(e){}
}

async function focusComment(postId){
    try{
        const data = await api(`/api/posts/${postId}/comments`);
        const box = document.getElementById("userListBody");
        box.innerHTML = "";
        document.getElementById("userListTitle").textContent = "Comments";

        if(data.comments.length === 0){
            box.innerHTML = `<div style="color:var(--muted);padding:10px 0">No comments yet.</div>`;
        }

        data.comments.forEach(c=>{
            const avatar = c.avatar || `https://i.pravatar.cc/100?u=${c.username}`;
            const row = document.createElement("div");
            row.className = "suggestion";
            row.innerHTML = `
                <div class="user-info">
                    <div class="avatar"><img src="${avatar}"></div>
                    <div>
                        <b style="font-size:13px">${escapeHtml(c.username)}</b>
                        <div style="font-size:13px">${escapeHtml(c.comment)}</div>
                    </div>
                </div>
                ${c.can_delete ? `<button class="follow-btn" style="color:#ff2d75" onclick="deleteComment(${c.id}, ${postId})">Delete</button>` : ""}
            `;
            box.appendChild(row);
        });

        document.getElementById("userListModal").classList.add("show");
        window.__activeCommentPostId = postId;
    }catch(e){}
}

async function deleteComment(commentId, postId){
    try{
        await api(`/api/comments/${commentId}`, { method:"DELETE" });
        showToast("Comment deleted");
        await focusComment(postId);
        await loadFeed();
    }catch(e){}
}

async function addComment(postId){
    const input = document.getElementById(`comment-${postId}`);
    const comment = input.value.trim();
    if(!comment){ return; }
    try{
        await api(`/api/posts/${postId}/comments`, {
            method:"POST",
            headers:{ "Content-Type":"application/json" },
            body:JSON.stringify({ comment })
        });
        input.value="";
        await loadFeed();
        showToast("Comment added");
    }catch(e){}
}

async function sharePost(postId){
    try{
        const data = await api("/api/users/chats");
        const box = document.getElementById("userListBody");
        box.innerHTML = "";
        document.getElementById("userListTitle").textContent = "Send to";

        data.users.forEach(u=>{
            const avatar = u.avatar || `https://i.pravatar.cc/100?u=${u.username}`;
            const row = document.createElement("div");
            row.className = "suggestion";
            row.innerHTML = `
                <div class="user-info">
                    <div class="avatar"><img src="${avatar}"></div>
                    <div class="user-name">${escapeHtml(u.username)}</div>
                </div>
                <button class="follow-btn" id="sendbtn-${u.id}">Send</button>
            `;
            row.querySelector("button").onclick = async ()=>{
                try{
                    await api("/api/messages", {
                        method:"POST",
                        headers:{ "Content-Type":"application/json" },
                        body:JSON.stringify({ receiver_id:u.id, post_id:postId })
                    });
                    document.getElementById(`sendbtn-${u.id}`).textContent = "Sent";
                    showToast("Post sent to " + u.username);
                }catch(e){}
            };
            box.appendChild(row);
        });

        document.getElementById("userListModal").classList.add("show");
    }catch(e){}
}

async function loadSuggestions(){
    const data = await api("/api/users/suggestions");
    const container = document.getElementById("suggestions");
    container.innerHTML="";
    data.users.forEach(user=>{
        const avatar = user.avatar || `https://i.pravatar.cc/100?u=${user.username}`;
        const div = document.createElement("div");
        div.className="suggestion";
        div.innerHTML = `
        <div class="user-info" style="cursor:pointer" onclick="viewUserProfile('${user.username}')">
            <div class="avatar"><img src="${avatar}"></div>
            <div>
                <div class="user-name">${escapeHtml(user.username)}</div>
                <div class="location">Suggested</div>
            </div>
        </div>
        <button class="follow-btn" onclick="toggleFollow(${user.id},this)">${user.following ? "Following" : "Follow"}</button>
        `;
        container.appendChild(div);
    });
}

async function toggleFollow(userId, button){
    try{
        const data = await api(`/api/users/${userId}/follow`, { method:"POST" });
        button.textContent = data.following ? "Following" : "Follow";
        showToast(data.following ? "Following user" : "Unfollowed user");
    }catch(e){}
}

async function loadStories(){
    const data = await api("/api/stories");
    const container = document.getElementById("stories");
    container.innerHTML="";

    const grouped = {};
    data.stories.forEach(story=>{
        if(!grouped[story.username]) grouped[story.username] = [];
        grouped[story.username].push(story);
    });

    const myStories = grouped[currentUser.username] || [];
    const yourStory = document.createElement("div");
    yourStory.className="story";
    yourStory.onclick = myStories.length > 0
        ? ()=>{ openStory(myStories, 0); }
        : ()=>{ showPage("create"); };

    if(myStories.length > 0){
        yourStory.innerHTML = `
            <div class="story-ring"><img src="${myStories[0].media_url}"></div>
            <p>Your story${myStories.length > 1 ? ` (${myStories.length})` : ""}</p>
        `;
    }else{
        yourStory.innerHTML = `
            <div class="story-ring" style="background:var(--border);position:relative">
                <img src="${ currentUser.avatar || 'https://i.pravatar.cc/150?img=12' }" style="border:3px solid var(--card)">
                <div style="position:absolute;bottom:-2px;right:-2px;width:22px;height:22px;border-radius:50%;background:var(--purple);color:white;display:flex;align-items:center;justify-content:center;font-size:14px;border:2px solid var(--card)">+</div>
            </div>
            <p>Your story</p>
        `;
    }
    container.appendChild(yourStory);

    Object.keys(grouped).forEach(username=>{
        if(username === currentUser.username) return;
        const stories = grouped[username];
        const div = document.createElement("div");
        div.className="story";
        div.onclick=()=>{ openStory(stories, 0); };
        div.innerHTML = `
            <div class="story-ring"><img src="${stories[0].media_url}"></div>
            <p>${escapeHtml(username)}${stories.length > 1 ? ` (${stories.length})` : ""}</p>
        `;
        container.appendChild(div);
    });
}

let currentStoryGroup = [];
let currentStoryIndex = 0;

function openStory(stories, index){
    currentStoryGroup = stories;
    currentStoryIndex = index;
    renderStoryFrame();
    document.getElementById("storyModal").classList.add("show");
}

function stopStoryMusic(){
    const audio = document.getElementById("storyMusicAudio");
    if(audio){ audio.pause(); audio.currentTime = 0; }
}

function renderStoryFrame(){
    stopStoryMusic();
    const story = currentStoryGroup[currentStoryIndex];
    document.getElementById("storyUser").textContent = "@" + story.username +
        (currentStoryGroup.length > 1 ? ` (${currentStoryIndex+1}/${currentStoryGroup.length})` : "");
    const imgEl = document.getElementById("storyImage");
    imgEl.src = story.media_url || "https://picsum.photos/seed/story/700/1200";

    const musicBox = document.getElementById("storyMusicBox");
    if(story.music_url){
        musicBox.innerHTML = `<audio id="storyMusicAudio" src="${story.music_url}" autoplay loop></audio>`;
        musicBox.querySelector("audio").play().catch(()=>{});
    }else{
        musicBox.innerHTML = "";
    }
}

function nextStory(){
    if(currentStoryIndex < currentStoryGroup.length - 1){
        currentStoryIndex++;
        renderStoryFrame();
    }else{
        closeStory();
    }
}

function prevStory(){
    if(currentStoryIndex > 0){
        currentStoryIndex--;
        renderStoryFrame();
    }
}

function closeStory(){
    stopStoryMusic();
    document.getElementById("storyModal").classList.remove("show");
}

let exploreSearchTimer;
function saveRecentSearch(term){
    if(!term) return;
    let list = JSON.parse(localStorage.getItem("orbit_recent_searches") || "[]");
    list = list.filter(t => t.toLowerCase() !== term.toLowerCase());
    list.unshift(term);
    list = list.slice(0, 8);
    localStorage.setItem("orbit_recent_searches", JSON.stringify(list));
}

function showRecentSearches(){
    const resultsBox = document.getElementById("exploreUserResults");
    const list = JSON.parse(localStorage.getItem("orbit_recent_searches") || "[]");
    if(list.length === 0){
        resultsBox.style.display = "none";
        document.getElementById("exploreGrid").style.display = "grid";
        return;
    }
    document.getElementById("exploreGrid").style.display = "none";
    resultsBox.style.display = "block";
    resultsBox.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0"><b style="font-size:13px">Recent</b><span style="font-size:12px;color:var(--purple);cursor:pointer" onclick="clearRecentSearches()">Clear all</span></div>`;
    list.forEach(term=>{
        const row = document.createElement("div");
        row.className = "chat";
        row.style.cursor = "pointer";
        row.innerHTML = `<div style="font-size:16px">🕓</div><div class="chat-name">${escapeHtml(term)}</div>`;
        row.onclick = ()=>{
            document.getElementById("exploreSearch").value = term;
            searchExplore();
        };
        resultsBox.appendChild(row);
    });
}

function clearRecentSearches(){
    localStorage.removeItem("orbit_recent_searches");
    showRecentSearches();
}

async function searchExplore(){
    const value = document.getElementById("exploreSearch").value.trim();
    clearTimeout(exploreSearchTimer);
    const resultsBox = document.getElementById("exploreUserResults");

    if(value.length < 1){
        resultsBox.innerHTML = "";
        resultsBox.style.display = "none";
        document.getElementById("exploreGrid").style.display = "grid";
        return;
    }

    saveRecentSearch(value);

    exploreSearchTimer = setTimeout(async()=>{
        try{
            document.getElementById("exploreGrid").style.display = "none";
            resultsBox.style.display = "block";

            if(value.startsWith("#")){
                const tag = value.slice(1).trim();
                if(!tag){ resultsBox.innerHTML = ""; return; }
                const data = await api("/api/posts/hashtag/" + encodeURIComponent(tag));
                if(data.posts.length === 0){
                    resultsBox.innerHTML = `<div style="color:var(--muted);padding:15px">No posts found for #${escapeHtml(tag)}.</div>`;
                    return;
                }
                resultsBox.innerHTML = `<div class="explore-grid" style="margin-top:0"></div>`;
                const grid = resultsBox.querySelector(".explore-grid");
                data.posts.forEach(post=>{
                    const div = document.createElement("div");
                    div.className = "explore-item";
                    div.innerHTML = post.media_type === "video"
                        ? `<video src="${post.media_url}" muted></video>`
                        : `<img src="${post.media_url}">`;
                    div.onclick = post.media_type === "video"
                        ? ()=>{ showPage("reels"); loadReels(post.id); }
                        : ()=>{ openPostLightbox(post); };
                    grid.appendChild(div);
                });
                return;
            }

            const data = await api("/api/users/search?q=" + encodeURIComponent(value));

            if(data.users.length === 0){
                resultsBox.innerHTML = `<div style="color:var(--muted);padding:15px">No user found with that ID.</div>`;
                return;
            }

            resultsBox.innerHTML = "";
            data.users.forEach(u=>{
                const avatar = u.avatar || `https://i.pravatar.cc/100?u=${u.username}`;
                const div = document.createElement("div");
                div.className = "chat";
                div.style.cursor = "pointer";
                div.onclick = ()=>{ viewUserProfile(u.username); };
                div.innerHTML = `
                    <div class="avatar"><img src="${avatar}"></div>
                    <div>
                        <div class="chat-name">@${escapeHtml(u.username)}</div>
                        <div class="chat-preview">${escapeHtml(u.full_name || "")}</div>
                    </div>
                `;
                resultsBox.appendChild(div);
            });
        }catch(e){}
    }, 300);
}

async function loadReels(startPostId){
    const data = await api("/api/posts");
    const container = document.getElementById("reelsContainer");
    container.innerHTML = "";
    const reels = data.posts.filter(p => p.media_type === "video");

    if(reels.length === 0){
        container.innerHTML = `<div style="text-align:center;color:var(--muted);padding:40px">No reels yet. Share the first one!</div>`;
        return;
    }

    reels.forEach(post=>{
        const div = document.createElement("div");
        div.className = "reel";
        div.id = `reel-${post.id}`;
        const avatar = post.avatar || `https://i.pravatar.cc/100?u=${post.username}`;
        const hasMusic = !!post.music_url;
        div.innerHTML = `
            <video src="${post.media_url}" loop playsinline ${hasMusic ? "muted" : ""}></video>
            ${hasMusic ? `<audio class="reel-audio" src="${post.music_url}" loop></audio>` : ""}
            <div class="reel-overlay">
                <div class="reel-user" style="cursor:pointer" onclick="closeAnyThenViewProfile('${post.username}')">@${escapeHtml(post.username)}${verifiedBadge(post.is_verified)}</div>
                <div class="reel-caption">${formatCaptionHtml(post.caption || "")}${hasMusic ? ` · 🎵 ${escapeHtml(post.music_name || "")}` : ""}</div>
                <div style="font-size:11px;opacity:.85;margin-top:4px">👁 ${formatCount(post.views)} views</div>
            </div>
            <div class="reel-actions">
                <button class="${post.liked ? 'liked' : ''}" onclick="likePost(${post.id}, this)">${post.liked ? "♥" : "♡"}</button>
                <button onclick="showToast('${post.comments_count} comments')">💬</button>
                <button onclick="sharePost(${post.id})">➤</button>
                <button onclick="savePost(${post.id}, this)">${post.saved ? "♣" : "♧"}</button>
            </div>
        `;
        div.onclick = (e)=>{
            if(e.target.tagName === "VIDEO"){
                const v = div.querySelector("video");
                if(v.paused){ v.play(); } else { v.pause(); }
            }
        };
        container.appendChild(div);
    });

    setupReelsAutoplay();

    if(startPostId){
        const el = document.getElementById(`reel-${startPostId}`);
        if(el) el.scrollIntoView({ behavior: "auto", block: "start" });
    }
}

let reelsObserver = null;
let reelsViewedThisSession = new Set();

function setupReelsAutoplay(){
    if(reelsObserver){ reelsObserver.disconnect(); }

    reelsObserver = new IntersectionObserver((entries)=>{
        entries.forEach(entry=>{
            const video = entry.target.querySelector("video");
            const audio = entry.target.querySelector(".reel-audio");
            if(!video) return;
            if(entry.isIntersecting && entry.intersectionRatio >= 0.6){
                video.currentTime = 0;
                video.play().catch(()=>{});
                if(audio){
                    audio.currentTime = 0;
                    audio.play().catch(()=>{});
                }
                const postId = entry.target.id.replace("reel-", "");
                if(postId && !reelsViewedThisSession.has(postId)){
                    reelsViewedThisSession.add(postId);
                    api(`/api/posts/${postId}/view`, { method:"POST" }).catch(()=>{});
                }
            }else{
                video.pause();
                if(audio) audio.pause();
            }
        });
    }, { threshold: [0, 0.6, 1] });

    document.querySelectorAll("#reelsContainer .reel").forEach(el=>{
        reelsObserver.observe(el);
    });
}

function closeAnyThenViewProfile(username){
    viewUserProfile(username);
}

let exploreTabMode = "all";

function setExploreTab(mode){
    exploreTabMode = mode;
    document.getElementById("exploreTabAll").classList.toggle("active", mode==="all");
    document.getElementById("exploreTabTrending").classList.toggle("active", mode==="trending");
    loadExplore();
}

function extractHashtags(text){
    const matches = (text || "").match(/#(\w+)/g) || [];
    return matches.map(t => t.slice(1).toLowerCase());
}

function scorePostsForYou(posts){
    const likedPosts = posts.filter(p => p.liked);
    const interestTags = new Set();
    likedPosts.forEach(p => extractHashtags(p.caption).forEach(t => interestTags.add(t)));

    if(interestTags.size === 0) return posts;

    return [...posts].sort((a, b)=>{
        const aScore = extractHashtags(a.caption).some(t => interestTags.has(t)) ? 1 : 0;
        const bScore = extractHashtags(b.caption).some(t => interestTags.has(t)) ? 1 : 0;
        return bScore - aScore;
    });
}

async function loadExplore(){
    const data = await api("/api/posts");
    const grid = document.getElementById("exploreGrid");
    grid.innerHTML="";

    let posts = data.posts;
    if(exploreTabMode === "trending"){
        posts = [...posts].sort((a,b)=> (b.likes + b.comments_count) - (a.likes + a.comments_count));
    }else{
        posts = scorePostsForYou(posts);
    }

    if(posts.length === 0){
        grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;color:var(--muted);padding:30px">No posts yet. Share your first post!</div>`;
        return;
    }
    posts.forEach(post=>{
        const div = document.createElement("div");
        div.className="explore-item";
        div.style.position = "relative";
        const mediaHtml = post.media_type === "video"
            ? `<video src="${post.media_url}" muted></video>`
            : `<img src="${post.media_url}">`;
        const trendingBadge = exploreTabMode === "trending"
            ? `<div style="position:absolute;top:6px;right:6px;background:rgba(0,0,0,.55);color:white;font-size:11px;padding:2px 7px;border-radius:8px">❤️ ${formatCount(post.likes)}</div>`
            : "";
        const playIcon = post.media_type === "video"
            ? `<div style="position:absolute;top:6px;left:6px;color:white;font-size:16px;text-shadow:0 1px 3px rgba(0,0,0,.7)">▶</div>`
            : "";
        div.innerHTML = mediaHtml + trendingBadge + playIcon;
        div.onclick = post.media_type === "video"
            ? ()=>{ showPage("reels"); loadReels(post.id); }
            : ()=>{ openPostLightbox(post); };
        grid.appendChild(div);
    });
}

function openPostLightbox(post){
    const modal = document.getElementById("postLightbox");
    const media = post.media_type === "video"
        ? `<video src="${post.media_url}" controls style="width:100%;max-height:70vh;object-fit:contain;background:#000"></video>`
        : `<img src="${post.media_url}" style="width:100%;max-height:70vh;object-fit:contain">`;
    document.getElementById("lightboxBody").innerHTML = `
        ${media}
        <div style="padding:15px">
            <div class="user-info" style="cursor:pointer;margin-bottom:10px" onclick="closeLightbox();viewUserProfile('${post.username}')">
                <div class="avatar"><img src="${post.avatar || 'https://i.pravatar.cc/100?u=' + post.username}"></div>
                <div class="user-name">${escapeHtml(post.username)}${verifiedBadge(post.is_verified)}</div>
            </div>
            <div class="caption">${escapeHtml(post.caption || "")}</div>
            <div class="likes" style="margin-top:8px">${post.likes} likes · ${post.comments_count} comments</div>
        </div>
    `;
    modal.classList.add("show");
}

function closeLightbox(){
    document.getElementById("postLightbox").classList.remove("show");
}

let viewingProfile = null;

function goToMyProfile(element){
    viewingProfile = null;
    showPage("profile", element);
    loadProfile();
}

function viewUserProfile(username){
    viewingProfile = username;
    showPage("profile");
    loadProfile();
}

async function loadProfile(){
    const username = viewingProfile || currentUser.username;
    const data = await api(`/api/users/${username}`);
    const user = data.user;
    const avatar = user.avatar || `https://i.pravatar.cc/300?u=${user.username}`;
    const header = document.getElementById("profileHeader");

    let actionButtons = "";
    let menuBtn = "";
    if(user.is_me){
        actionButtons = `
            <button class="edit-btn" onclick="editProfile()">Edit profile</button>
            <button class="edit-btn" onclick="showToast('Profile link copied')">Share profile</button>
        `;
        menuBtn = `<button class="icon-btn" style="margin-left:auto" onclick="openProfileMenu()">☰</button>`;
    }else{
        actionButtons = `
            <button class="edit-btn" style="background:${user.is_following ? 'var(--bg)' : 'var(--purple)'};color:${user.is_following ? 'var(--text)' : 'white'};border:${user.is_following ? '1px solid var(--border)' : 'none'}" onclick="toggleFollowProfile(${user.id})">
                ${user.is_following ? "Following" : "Follow"}
            </button>
            <button class="edit-btn" onclick="messageFromProfile(${user.id}, '${escapeHtml(user.username)}')">Message</button>
        `;
    }

    header.innerHTML = `
        <div style="display:flex;align-items:center;margin-bottom:14px">
            <b style="font-size:16px">${escapeHtml(user.username)}${verifiedBadge(user.is_verified)}</b>
            ${menuBtn}
        </div>
        <div class="profile-top-row">
            <div class="big-avatar"><img src="${avatar}"></div>
            <div class="profile-stats-row">
                <div><strong>${formatCount(user.posts)}</strong><span>posts</span></div>
                <div style="cursor:pointer" onclick="showUserList('${escapeHtml(user.username)}','followers')"><strong>${formatCount(user.followers)}</strong><span>followers</span></div>
                <div style="cursor:pointer" onclick="showUserList('${escapeHtml(user.username)}','following')"><strong>${formatCount(user.following)}</strong><span>following</span></div>
            </div>
        </div>
        <div class="profile-info">
            <div class="profile-name">
                <h2>${escapeHtml(user.full_name || user.username)}</h2>
            </div>
            <div class="bio">${escapeHtml(user.bio || "")}</div>
            ${user.profile_music_url ? `
                <div style="display:flex;align-items:center;gap:8px;margin-top:10px;background:var(--bg);border:1px solid var(--border);padding:7px 12px;border-radius:10px;max-width:320px">
                    <span>🎵</span>
                    <span style="font-size:12px;flex:1">${escapeHtml(user.profile_music_name || "Music")}</span>
                    <audio controls style="height:28px;max-width:150px" src="${user.profile_music_url}"></audio>
                </div>
            ` : ""}
            <div class="profile-actions" style="margin-top:14px">
                ${actionButtons}
                ${user.is_me ? "" : `<button class="edit-btn" style="background:var(--bg);border:1px solid var(--border);padding:8px 12px" onclick="promptBlockUser(${user.id}, '${escapeHtml(user.username)}')">⋯</button>`}
            </div>
        </div>
        <div class="stories" id="highlightsRow" style="padding:5px 0 15px"></div>
        <div class="profile-tabs">
            <button class="profile-tab active" onclick="setProfileTab('posts',this)">▦</button>
            <button class="profile-tab" onclick="setProfileTab('reels',this)">▷</button>
            <button class="profile-tab" onclick="setProfileTab('tagged',this)">☺</button>
        </div>
    `;

    window.__profilePosts = data.posts;
    renderProfileGrid("posts");
    await loadHighlights(user.username, user.is_me);
}

function setProfileTab(tab, el){
    document.querySelectorAll(".profile-tab").forEach(t=>t.classList.remove("active"));
    if(el) el.classList.add("active");
    renderProfileGrid(tab);
}

function renderProfileGrid(tab){
    const grid = document.getElementById("profileGrid");
    grid.innerHTML="";
    const posts = window.__profilePosts || [];

    if(tab === "tagged"){
        grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;color:var(--muted);padding:40px">No tagged posts.</div>`;
        return;
    }

    const filtered = posts.filter(p => tab === "reels" ? p.media_type === "video" : p.media_type === "image");

    if(filtered.length === 0){
        grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;color:var(--muted);padding:40px">${tab === "reels" ? "No reels yet." : "No posts yet."}</div>`;
        return;
    }

    filtered.forEach(post=>{
        if(post.media_type === "video"){
            const video = document.createElement("video");
            video.src = post.media_url;
            video.muted = true;
            grid.appendChild(video);
        }else{
            const img = document.createElement("img");
            img.src = post.media_url;
            grid.appendChild(img);
        }
    });
}

async function loadHighlights(username, isMe){
    const data = await api(`/api/highlights/${username}`);
    const row = document.getElementById("highlightsRow");
    row.innerHTML = "";

    if(isMe){
        const addDiv = document.createElement("div");
        addDiv.className = "story";
        addDiv.onclick = openAddHighlight;
        addDiv.innerHTML = `
            <div class="story-ring" style="background:var(--border)">
                <div style="width:100%;height:100%;border-radius:50%;background:var(--card);display:flex;align-items:center;justify-content:center;font-size:22px">+</div>
            </div>
            <p>New</p>
        `;
        row.appendChild(addDiv);
    }

    data.highlights.forEach(h=>{
        h.isMine = isMe;
        const div = document.createElement("div");
        div.className = "story";
        div.onclick = ()=>{ openHighlightViewer(h); };
        div.innerHTML = `
            <div class="story-ring"><img src="${h.media_url}"></div>
            <p>${escapeHtml(h.title)}</p>
        `;
        row.appendChild(div);
    });
}

async function openAddHighlight(){
    const title = prompt("Highlight title (e.g. Travel, Friends):");
    if(!title || !title.trim()) return;

    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*,video/*";
    input.onchange = async ()=>{
        const file = input.files[0];
        if(!file) return;
        const formData = new FormData();
        formData.append("title", title.trim());
        formData.append("file", file);
        try{
            await api("/api/highlights", { method:"POST", body:formData });
            await loadProfile();
            showToast("Highlight added");
        }catch(e){}
    };
    input.click();
}

function openHighlightViewer(h){
    const media = h.media_type === "video"
        ? `<video src="${h.media_url}" controls autoplay style="width:100%;max-height:80vh;object-fit:contain;background:#000"></video>`
        : `<img src="${h.media_url}" style="width:100%;max-height:80vh;object-fit:contain">`;
    document.getElementById("lightboxBody").innerHTML = `
        ${media}
        <div style="padding:15px;display:flex;justify-content:space-between;align-items:center">
            <b>${escapeHtml(h.title)}</b>
            ${h.isMine ? `<button class="edit-btn" onclick="deleteHighlight(${h.id})">Delete</button>` : ""}
        </div>
    `;
    document.getElementById("postLightbox").classList.add("show");
}

async function deleteHighlight(id){
    try{
        await api(`/api/highlights/${id}`, { method:"DELETE" });
        closeLightbox();
        await loadProfile();
        showToast("Highlight removed");
    }catch(e){}
}

/* ===================== VIDEO CALL (experimental, WebRTC + polling signaling) ===================== */
let rtcPeer = null;
let localStream = null;
let callPollTimer = null;
let lastSignalId = 0;
let callPeerId = null;
let callPeerName = "";
let isCallInitiator = false;

const RTC_CONFIG = { iceServers: [{ urls: "stun:stun.l.google.com:19302" }] };

async function startCall(peerId, peerName){
    callPeerId = peerId;
    callPeerName = peerName;
    isCallInitiator = true;
    document.getElementById("callStatusText").textContent = `Calling ${peerName}...`;
    document.getElementById("callModal").classList.add("show");

    try{
        localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        document.getElementById("localVideo").srcObject = localStream;
    }catch(e){
        showToast("Camera/mic access denied or unavailable");
        closeCallUI();
        return;
    }

    setupPeerConnection();
    localStream.getTracks().forEach(track => rtcPeer.addTrack(track, localStream));

    const offer = await rtcPeer.createOffer();
    await rtcPeer.setLocalDescription(offer);
    await sendCallSignal(peerId, "offer", offer);

    startSignalPolling();
}

function setupPeerConnection(){
    rtcPeer = new RTCPeerConnection(RTC_CONFIG);

    rtcPeer.ontrack = (event)=>{
        document.getElementById("remoteVideo").srcObject = event.streams[0];
        document.getElementById("callStatusText").textContent = `In call with ${callPeerName}`;
    };

    rtcPeer.onicecandidate = (event)=>{
        if(event.candidate && callPeerId){
            sendCallSignal(callPeerId, "candidate", event.candidate);
        }
    };
}

async function sendCallSignal(toId, type, payload){
    try{
        await api("/api/calls/signal", {
            method:"POST",
            headers:{ "Content-Type":"application/json" },
            body:JSON.stringify({ to_id: toId, type, payload })
        });
    }catch(e){}
}

function startSignalPolling(){
    stopSignalPolling();
    callPollTimer = setInterval(async ()=>{
        try{
            const data = await api(`/api/calls/poll?since=${lastSignalId}`);
            for(const sig of data.signals){
                lastSignalId = Math.max(lastSignalId, sig.id);
                await handleCallSignal(sig);
            }
        }catch(e){}
    }, 1200);
}

function stopSignalPolling(){
    if(callPollTimer){ clearInterval(callPollTimer); callPollTimer = null; }
}

async function handleCallSignal(sig){
    if(sig.type === "offer"){
        if(document.getElementById("callModal").classList.contains("show")) return;
        callPeerId = sig.from_id;
        isCallInitiator = false;
        window.__pendingOffer = sig.payload;
        const caller = Object.values(window.__feedPostsCache || {}).find(p=>p.user_id===sig.from_id);
        document.getElementById("incomingCallText").textContent = "Incoming video call...";
        document.getElementById("incomingCallModal").classList.add("show");
        startSignalPolling();
        return;
    }

    if(!rtcPeer) return;

    if(sig.type === "answer"){
        await rtcPeer.setRemoteDescription(new RTCSessionDescription(sig.payload));
    }else if(sig.type === "candidate"){
        try{ await rtcPeer.addIceCandidate(new RTCIceCandidate(sig.payload)); }catch(e){}
    }else if(sig.type === "end"){
        closeCallUI();
        showToast("Call ended");
    }
}

async function acceptIncomingCall(){
    document.getElementById("incomingCallModal").classList.remove("show");
    document.getElementById("callStatusText").textContent = "Connecting...";
    document.getElementById("callModal").classList.add("show");

    try{
        localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        document.getElementById("localVideo").srcObject = localStream;
    }catch(e){
        showToast("Camera/mic access denied or unavailable");
        closeCallUI();
        return;
    }

    setupPeerConnection();
    localStream.getTracks().forEach(track => rtcPeer.addTrack(track, localStream));

    await rtcPeer.setRemoteDescription(new RTCSessionDescription(window.__pendingOffer));
    const answer = await rtcPeer.createAnswer();
    await rtcPeer.setLocalDescription(answer);
    await sendCallSignal(callPeerId, "answer", answer);
}

function declineIncomingCall(){
    document.getElementById("incomingCallModal").classList.remove("show");
    if(callPeerId){ sendCallSignal(callPeerId, "end", {}); }
    callPeerId = null;
}

function endCall(){
    if(callPeerId){ sendCallSignal(callPeerId, "end", {}); }
    closeCallUI();
}

function closeCallUI(){
    stopSignalPolling();
    if(localStream){ localStream.getTracks().forEach(t=>t.stop()); localStream = null; }
    if(rtcPeer){ rtcPeer.close(); rtcPeer = null; }
    document.getElementById("callModal").classList.remove("show");
    document.getElementById("localVideo").srcObject = null;
    document.getElementById("remoteVideo").srcObject = null;
    callPeerId = null;
}

async function toggleFollowProfile(userId){
    try{
        const data = await api(`/api/users/${userId}/follow`, { method:"POST" });
        showToast(data.following ? "Following user" : "Unfollowed user");
        await loadProfile();
    }catch(e){}
}

function messageFromProfile(userId, username){
    showPage("messages");
    selectChat({ id:userId, username:username });
}

function editProfile(){
    document.getElementById("editFullName").value = currentUser.full_name || "";
    document.getElementById("editBio").value = currentUser.bio || "";
    document.getElementById("editProfileModal").classList.add("show");
}

async function uploadAvatar(event){
    const file = event.target.files[0];
    if(!file) return;
    const formData = new FormData();
    formData.append("file", file);
    try{
        const data = await api("/api/profile/avatar", { method:"POST", body:formData });
        currentUser = data.user;
        updateMiniProfile();
        await loadProfile();
        showToast("Profile photo updated");
    }catch(e){}
}

async function uploadProfileMusic(event){
    const file = event.target.files[0];
    if(!file) return;
    const formData = new FormData();
    formData.append("music", file);
    try{
        const data = await api("/api/profile/music", { method:"POST", body:formData });
        currentUser = data.user;
        await loadProfile();
        showToast("Profile music updated");
    }catch(e){}
}

async function removeProfileMusic(){
    try{
        const data = await api("/api/profile/music", { method:"DELETE" });
        currentUser = data.user;
        await loadProfile();
        showToast("Profile music removed");
    }catch(e){}
}

function closeEditProfile(){
    document.getElementById("editProfileModal").classList.remove("show");
}

async function saveProfileEdit(){
    const name = document.getElementById("editFullName").value.trim();
    const bio = document.getElementById("editBio").value.trim();
    if(!name){
        showToast("Full name cannot be empty");
        return;
    }
    try{
        const data = await api("/api/profile", {
            method:"PUT",
            headers:{ "Content-Type":"application/json" },
            body:JSON.stringify({ full_name:name, bio:bio || "" })
        });
        currentUser = data.user;
        closeEditProfile();
        await loadProfile();
        updateMiniProfile();
        showToast("Profile updated successfully");
    }catch(e){}
}

async function showUserList(username, type){
    try{
        const data = await api(`/api/users/${username}/${type}`);
        document.getElementById("userListTitle").textContent = type === "followers" ? "Followers" : "Following";
        const body = document.getElementById("userListBody");
        body.innerHTML = "";
        if(data.users.length === 0){
            body.innerHTML = `<div class="location">No users yet.</div>`;
        }
        data.users.forEach(u=>{
            const avatar = u.avatar || `https://i.pravatar.cc/100?u=${u.username}`;
            const div = document.createElement("div");
            div.className="suggestion";
            div.innerHTML = `
                <div class="user-info">
                    <div class="avatar"><img src="${avatar}"></div>
                    <div class="user-name">${escapeHtml(u.username)}</div>
                </div>
            `;
            body.appendChild(div);
        });
        document.getElementById("userListModal").classList.add("show");
    }catch(e){}
}

function closeUserListModal(){
    document.getElementById("userListModal").classList.remove("show");
}

function updateMiniProfile(){
    const box = document.getElementById("miniProfile");
    if(!box || !currentUser){ return; }
    const avatar = currentUser.avatar || `https://i.pravatar.cc/100?u=${currentUser.username}`;
    box.innerHTML = `
        <div class="avatar"><img src="${avatar}"></div>
        <div>
            <b>${escapeHtml(currentUser.username)}</b>
            <div class="location">Welcome to Orbit</div>
        </div>
    `;
}

async function loadChats(){
    const data = await api("/api/users/chats");
    const list = document.getElementById("chatList");
    list.innerHTML="";
    data.users.forEach(user=>{
        const avatar = user.avatar || `https://i.pravatar.cc/100?u=${user.username}`;
        const div = document.createElement("div");
        div.className="chat";
        div.id = `chatrow-${user.id}`;
        div.onclick=()=>{ selectChat(user); };
        let preview = "Start a conversation";
        if(user.last_image){
            preview = "📷 Photo";
        }else if(user.last_message){
            preview = user.last_message.length > 28 ? user.last_message.slice(0,28)+"…" : user.last_message;
        }
        const timeLabel = user.last_time ? formatChatTime(user.last_time) : "";
        div.innerHTML = `
            <div class="avatar"><img src="${avatar}"></div>
            <div style="min-width:0;flex:1">
                <div class="chat-name">${escapeHtml(user.username)}</div>
                <div class="chat-preview" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(preview)}</div>
            </div>
            ${timeLabel ? `<div style="font-size:11px;color:var(--muted);flex-shrink:0;align-self:flex-start;margin-top:2px">${timeLabel}</div>` : ""}
        `;
        list.appendChild(div);
    });
}

function formatCount(n){
    n = Number(n) || 0;
    if(n >= 1000000) return (n/1000000).toFixed(n % 1000000 === 0 ? 0 : 1) + "M";
    if(n >= 1000) return (n/1000).toFixed(n % 1000 === 0 ? 0 : 1) + "K";
    return String(n);
}

function verifiedBadge(isVerified){
    return isVerified ? `<span title="Verified" style="color:#2563eb;font-size:13px;margin-left:3px">✔</span>` : "";
}

function formatChatTime(isoString){
    const date = new Date(isoString);
    const now = new Date();
    const sameDay = date.toDateString() === now.toDateString();
    if(sameDay){
        return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    }
    return date.toLocaleDateString([], { day: "numeric", month: "short" });
}

async function selectChat(user){
    selectedChatUser = user;
    document.querySelectorAll(".chat").forEach(c=>{ c.classList.remove("selected"); });
    const row = document.getElementById(`chatrow-${user.id}`);
    if(row) row.classList.add("selected");

    const avatar = user.avatar || `https://i.pravatar.cc/100?u=${user.username}`;
    document.getElementById("chatHeader").innerHTML = `
        <div class="avatar" style="cursor:pointer" onclick="viewUserProfile('${user.username}')"><img src="${avatar}"></div>
        <div style="flex:1">
            <b style="font-size:14.5px;cursor:pointer" onclick="viewUserProfile('${user.username}')">${escapeHtml(user.username)}</b>
        </div>
        <button class="icon-btn" title="Video call" onclick="startCall(${user.id}, '${escapeHtml(user.username)}')">📹</button>
    `;

    await renderChatMessages(user.id);
    startChatAutoRefresh(user.id);
}

let chatRefreshTimer = null;
let lastMessageCount = 0;

async function renderChatMessages(userId){
    const data = await api(`/api/messages/${userId}`);
    lastMessageCount = data.messages.length;

    const container = document.getElementById("chatMessages");
    container.innerHTML="";

    data.messages.forEach((message, idx)=>{
        const isSent = message.sender_id === currentUser.id;
        const nextMsg = data.messages[idx+1];
        const isLastInGroup = !nextMsg || nextMsg.sender_id !== message.sender_id;

        const row = document.createElement("div");
        row.className = "message-row " + (isSent ? "sent-row" : "received-row");

        const bubble = document.createElement("div");
        bubble.className = "message " + (isSent ? "sent" : "received");

        if(message.image_url){
            bubble.style.padding = "4px";
            bubble.innerHTML = `<img src="${message.image_url}" style="max-width:220px;border-radius:14px;display:block">${message.message ? `<div style="padding:6px 8px">${escapeHtml(message.message)}</div>` : ""}`;
        }else{
            bubble.textContent = message.message;
        }
        row.appendChild(bubble);

        if(isLastInGroup){
            const timeEl = document.createElement("div");
            timeEl.className = "message-time";
            timeEl.textContent = formatChatTime(message.created_at);
            row.appendChild(timeEl);
        }

        container.appendChild(row);
    });

    container.scrollTop = container.scrollHeight;
}

function startChatAutoRefresh(userId){
    stopChatAutoRefresh();
    chatRefreshTimer = setInterval(async ()=>{
        if(!selectedChatUser || selectedChatUser.id !== userId) return;
        try{
            const data = await api(`/api/messages/${userId}`);
            if(data.messages.length !== lastMessageCount){
                await renderChatMessages(userId);
                await loadChats();
            }
        }catch(e){}
    }, 4000);
}

function stopChatAutoRefresh(){
    if(chatRefreshTimer){ clearInterval(chatRefreshTimer); chatRefreshTimer = null; }
}

const EMOJI_LIST = ["😀","😁","😂","🤣","😊","😍","😘","😎","🤔","😢","😭","😡","👍","👎","👏","🙏","🔥","❤️","💯","🎉","😅","😉","🥰","😴","😇","🤗","😜","🙌","👋","✨"];

function toggleEmojiPicker(){
    const picker = document.getElementById("emojiPicker");
    if(picker.style.display === "flex"){
        picker.style.display = "none";
        return;
    }
    if(picker.children.length === 0){
        EMOJI_LIST.forEach(e=>{
            const btn = document.createElement("button");
            btn.textContent = e;
            btn.style.cssText = "border:0;background:none;font-size:20px;cursor:pointer;padding:4px;";
            btn.onclick = ()=>{ insertEmoji(e); };
            picker.appendChild(btn);
        });
    }
    picker.style.display = "flex";
}

function insertEmoji(emoji){
    const input = document.getElementById("messageInput");
    input.value += emoji;
    input.focus();
}

async function sendChatImage(event){
    const file = event.target.files[0];
    if(!file || !selectedChatUser){ return; }
    const formData = new FormData();
    formData.append("receiver_id", selectedChatUser.id);
    formData.append("message", "");
    formData.append("image", file);
    try{
        await api("/api/messages", { method:"POST", body:formData });
        event.target.value = "";
        await selectChat(selectedChatUser);
        await loadChats();
    }catch(e){}
}

async function sendMessage(){
    if(!selectedChatUser){
        showToast("Select a chat first");
        return;
    }
    const input = document.getElementById("messageInput");
    const message = input.value.trim();
    if(!message){ return; }
    try{
        await api("/api/messages", {
            method:"POST",
            headers:{ "Content-Type":"application/json" },
            body:JSON.stringify({ receiver_id: selectedChatUser.id, message })
        });
        input.value="";
        await selectChat(selectedChatUser);
        await loadChats();
    }catch(e){}
}

let notifTabMode = "you";

function setNotifTab(mode){
    notifTabMode = mode;
    document.getElementById("notifTabYou").classList.toggle("active", mode==="you");
    document.getElementById("notifTabFollowing").classList.toggle("active", mode==="following");
    if(mode === "you"){
        loadNotifications();
    }else{
        loadActivityFeed();
    }
}

async function loadActivityFeed(){
    const list = document.getElementById("notificationList");
    list.innerHTML = "";
    try{
        const data = await api("/api/activity");
        if(data.activity.length === 0){
            list.innerHTML = `<div class="notification"><div class="notification-text">No activity from people you follow yet.</div>🔔</div>`;
            return;
        }
        const iconFor = { like: "❤️", comment: "💬", follow: "👤" };
        data.activity.forEach(a=>{
            const div = document.createElement("div");
            div.className = "notification";
            div.style.cursor = "pointer";
            const avatar = a.avatar || `https://i.pravatar.cc/100?u=${a.username}`;
            div.innerHTML = `
                <div class="avatar"><img src="${avatar}"></div>
                <div class="notification-text">${escapeHtml(a.text)}<div style="color:var(--muted);font-size:11px;margin-top:3px">${formatChatTime(a.created_at)}</div></div>
                ${a.media_url ? `<img src="${a.media_url}" style="width:38px;height:38px;object-fit:cover;border-radius:6px">` : ""}
            `;
            div.onclick = ()=>{ viewUserProfile(a.username); };
            list.appendChild(div);
        });
    }catch(e){}
}

async function loadNotifications(){
    const data = await api("/api/notifications");
    const list = document.getElementById("notificationList");
    list.innerHTML="";
    updateNotifBadge();
    if(data.notifications.length === 0){
        list.innerHTML = `<div class="notification"><div class="notification-text">No new notifications.</div>🔔</div>`;
        return;
    }
    const iconFor = { like: "❤️", comment: "💬", follow: "👤", message: "✉️" };
    data.notifications.forEach(n=>{
        const div = document.createElement("div");
        div.className="notification";
        if(!n.is_read){
            div.style.borderLeft = "3px solid var(--purple)";
        }
        div.style.cursor = "pointer";
        div.innerHTML = `
            <div class="avatar" style="background:var(--bg);color:var(--text);font-size:18px">${iconFor[n.type] || "🔔"}</div>
            <div class="notification-text">${escapeHtml(n.text)}<div style="color:var(--muted);font-size:11px;margin-top:3px">${formatChatTime(n.created_at)}</div></div>
        `;
        div.onclick = ()=>{
            if(n.actor_username){ viewUserProfile(n.actor_username); }
        };
        list.appendChild(div);
    });
}

const FILTERS = [
    { name: "", label: "Normal" },
    { name: "grayscale", label: "B&W" },
    { name: "sepia", label: "Sepia" },
    { name: "warm", label: "Warm" },
    { name: "cool", label: "Cool" },
    { name: "contrast", label: "Vivid" },
    { name: "fade", label: "Fade" }
];
let selectedFilter = "";

function handleDragOver(event){
    event.preventDefault();
    document.getElementById("uploadArea").style.borderColor = "var(--purple)";
}

function handleDragLeave(event){
    document.getElementById("uploadArea").style.borderColor = "";
}

function handleDrop(event){
    event.preventDefault();
    document.getElementById("uploadArea").style.borderColor = "";
    const files = event.dataTransfer.files;
    if(files && files.length > 0){
        previewMedia({ target: { files } });
    }
}

function previewMedia(event){
    const files = Array.from(event.target.files || []);
    if(files.length === 0) return;

    if(files.length > 1 && createMode === "post"){
        selectedFiles = files.slice(0, 10);
        selectedFile = selectedFiles[0];
        renderMultiPreview();
        buildFilterRow();
        updatePreviewOverlay();
        return;
    }

    selectedFiles = [files[0]];
    selectedFile = files[0];
    const file = files[0];
    const area = document.getElementById("uploadArea");
    area.innerHTML="";
    if(file.type.startsWith("image/")){
        const img = document.createElement("img");
        img.id = "previewMediaEl";
        img.src = URL.createObjectURL(file);
        img.style.width = "100%";
        area.appendChild(img);
    }else{
        const video = document.createElement("video");
        video.id = "previewMediaEl";
        video.src = URL.createObjectURL(file);
        video.controls=true;
        area.appendChild(video);
    }

    const overlaySpan = document.createElement("div");
    overlaySpan.className = "preview-overlay-text";
    overlaySpan.id = "previewOverlayText";
    area.appendChild(overlaySpan);

    const changeLabel = document.createElement("label");
    changeLabel.className = "upload-label";
    changeLabel.htmlFor = "createFile";
    changeLabel.style.marginTop = "10px";
    changeLabel.textContent = "Change file";
    area.appendChild(changeLabel);

    const hiddenInput = document.createElement("input");
    hiddenInput.type = "file";
    hiddenInput.id = "createFile";
    hiddenInput.accept = "image/*,video/*";
    hiddenInput.multiple = createMode === "post";
    hiddenInput.style.display = "none";
    hiddenInput.onchange = previewMedia;
    area.appendChild(hiddenInput);

    buildFilterRow();
    updatePreviewOverlay();
    applyFilterToPreview();
}

function renderMultiPreview(){
    const area = document.getElementById("uploadArea");
    area.innerHTML = "";
    const strip = document.createElement("div");
    strip.style.cssText = "display:flex;gap:8px;overflow-x:auto;width:100%;padding:10px";
    selectedFiles.forEach((f, i)=>{
        const thumb = f.type.startsWith("image/")
            ? document.createElement("img")
            : document.createElement("video");
        thumb.src = URL.createObjectURL(f);
        thumb.style.cssText = "width:90px;height:90px;object-fit:cover;border-radius:10px;flex-shrink:0";
        if(i === 0) thumb.id = "previewMediaEl";
        strip.appendChild(thumb);
    });
    area.appendChild(strip);

    const badge = document.createElement("div");
    badge.style.cssText = "font-size:12px;color:var(--muted)";
    badge.textContent = `${selectedFiles.length} photos/videos selected`;
    area.appendChild(badge);

    const overlaySpan = document.createElement("div");
    overlaySpan.className = "preview-overlay-text";
    overlaySpan.id = "previewOverlayText";
    area.appendChild(overlaySpan);

    const changeLabel = document.createElement("label");
    changeLabel.className = "upload-label";
    changeLabel.htmlFor = "createFile";
    changeLabel.style.marginTop = "10px";
    changeLabel.textContent = "Change selection";
    area.appendChild(changeLabel);

    const hiddenInput = document.createElement("input");
    hiddenInput.type = "file";
    hiddenInput.id = "createFile";
    hiddenInput.accept = "image/*,video/*";
    hiddenInput.multiple = true;
    hiddenInput.style.display = "none";
    hiddenInput.onchange = previewMedia;
    area.appendChild(hiddenInput);
}

function buildFilterRow(){
    const row = document.getElementById("filterRow");
    row.innerHTML = "";
    if(!selectedFile) return;
    const previewUrl = URL.createObjectURL(selectedFile);
    FILTERS.forEach(f=>{
        const sw = document.createElement("div");
        sw.className = "filter-swatch" + (selectedFilter === f.name ? " active" : "");
        const cls = f.name ? "f-" + f.name : "";
        sw.innerHTML = selectedFile.type.startsWith("video/")
            ? `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:var(--bg);font-size:10px" class="${cls}">${escapeHtml(f.label)}</div>`
            : `<img src="${previewUrl}" class="${cls}">`;
        sw.title = f.label;
        sw.onclick = ()=>{
            selectedFilter = f.name;
            buildFilterRow();
            applyFilterToPreview();
        };
        row.appendChild(sw);
    });
}

function applyFilterToPreview(){
    const el = document.getElementById("previewMediaEl");
    if(!el) return;
    el.className = selectedFilter ? "f-" + selectedFilter : "";
}

function updatePreviewOverlay(){
    const el = document.getElementById("previewOverlayText");
    if(!el) return;
    el.textContent = document.getElementById("overlayTextInput").value.trim();
}

let createMode = "post";

function setCreateMode(mode){
    createMode = mode;
    document.getElementById("createPostTab").classList.toggle("active", mode==="post");
    document.getElementById("createReelTab").classList.toggle("active", mode==="reel");
    document.getElementById("createStoryTab").classList.toggle("active", mode==="story");
    document.getElementById("captionInput").style.display = mode==="story" ? "none" : "block";
    const input = document.getElementById("uploadArea").querySelector("input");
    if(input){
        input.setAttribute("accept", mode==="reel" ? "video/*" : "image/*,video/*");
        input.multiple = mode === "post";
    }
    document.getElementById("publishBtn").textContent =
        mode==="post" ? "Share Post" : mode==="reel" ? "Share Reel" : "Share Story";
}

function uploadWithProgress(url, formData){
    return new Promise((resolve, reject)=>{
        const xhr = new XMLHttpRequest();
        xhr.open("POST", url);
        xhr.withCredentials = true;

        const bar = document.getElementById("uploadProgressBar");
        const fill = document.getElementById("uploadProgressFill");
        bar.style.display = "block";
        fill.style.width = "0%";

        xhr.upload.onprogress = (event)=>{
            if(event.lengthComputable){
                const pct = Math.round((event.loaded / event.total) * 100);
                fill.style.width = pct + "%";
            }
        };

        xhr.onload = ()=>{
            bar.style.display = "none";
            try{
                const data = JSON.parse(xhr.responseText);
                if(xhr.status >= 200 && xhr.status < 300 && data.success){
                    resolve(data);
                }else{
                    showToast(data.message || "Upload failed");
                    reject(new Error(data.message || "Upload failed"));
                }
            }catch(e){
                showToast("Upload failed");
                reject(e);
            }
        };

        xhr.onerror = ()=>{
            bar.style.display = "none";
            showToast("Network error during upload");
            reject(new Error("Network error"));
        };

        xhr.send(formData);
    });
}

async function publishPost(){
    const file = selectedFile;
    const caption = document.getElementById("captionInput").value.trim();
    const overlayText = document.getElementById("overlayTextInput").value.trim();
    const location = document.getElementById("locationInput").value.trim();
    if(!file){
        showToast(createMode==="reel" ? "Please select a video" : "Please select a photo or video");
        return;
    }
    if(createMode === "reel" && !file.type.startsWith("video/")){
        showToast("Reels must be a video file");
        return;
    }
    const formData = new FormData();
    if(createMode === "post" && selectedFiles.length > 1){
        selectedFiles.forEach(f=>{ formData.append("files", f); });
    }else{
        formData.append("file", file);
    }

    const publishBtn = document.getElementById("publishBtn");
    publishBtn.disabled = true;
    const originalBtnText = publishBtn.textContent;
    publishBtn.textContent = "Uploading...";

    try{
        if(createMode === "story"){
            if(selectedMusic){
                formData.append("music", selectedMusic);
            }
            await uploadWithProgress("/api/stories", formData);
            resetUpload();
            await loadStories();
            showPage("home");
            showToast("Story added successfully");
        }else{
            formData.append("caption", caption);
            formData.append("filter_name", selectedFilter);
            formData.append("overlay_text", overlayText);
            formData.append("location", location);
            if(selectedMusic){
                formData.append("music", selectedMusic);
            }
            await uploadWithProgress("/api/posts", formData);
            document.getElementById("captionInput").value="";
            resetUpload();
            await loadFeed();
            await loadExplore();
            await loadProfile();
            if(createMode === "reel"){
                await loadReels();
            }
            showPage(createMode === "reel" ? "reels" : "home");
            showToast(createMode === "reel" ? "Reel shared successfully" : "Post created successfully");
        }
    }catch(e){
    }finally{
        publishBtn.disabled = false;
        publishBtn.textContent = originalBtnText;
    }
}

function resetUpload(){
    selectedFile = null;
    selectedFiles = [];
    selectedMusic = null;
    selectedFilter = "";
    const overlayInput = document.getElementById("overlayTextInput");
    if(overlayInput) overlayInput.value = "";
    const filterRow = document.getElementById("filterRow");
    if(filterRow) filterRow.innerHTML = "";
    const musicInput = document.getElementById("musicFile");
    if(musicInput) musicInput.value = "";
    const musicBox = document.getElementById("musicPreview");
    if(musicBox) musicBox.textContent = "";
    const area = document.getElementById("uploadArea");
    area.innerHTML = `
        <div style="font-size:45px">📸</div>
        <b>Select a photo or video</b>
        <label class="upload-label" for="createFile">Choose from device</label>
        <input id="createFile" type="file" accept="image/*,video/*" ${createMode==="post" ? "multiple" : ""} onchange="previewMedia(event)">
    `;
}

async function togglePrivate(){
    try{
        const data = await api("/api/profile/privacy", { method:"POST" });
        document.getElementById("privateToggle").classList.toggle("active", data.is_private);
        document.getElementById("privacyStatusText").textContent = data.is_private ? "Private" : "Public";
        showToast(data.is_private ? "Private account enabled" : "Private account disabled");
    }catch(e){}
}

async function toggleCommentsSetting(){
    try{
        const data = await api("/api/profile/comments-toggle", { method:"POST" });
        document.getElementById("commentsToggle").classList.toggle("active", data.comments_enabled);
        showToast(data.comments_enabled ? "Comments enabled" : "Comments turned off");
    }catch(e){}
}

async function initSettingsPage(){
    document.getElementById("privateToggle").classList.toggle("active", !!currentUser.is_private);
    document.getElementById("privacyStatusText").textContent = currentUser.is_private ? "Private" : "Public";
    document.getElementById("commentsToggle").classList.toggle("active", currentUser.comments_enabled !== false);

    const showAdmin = !!currentUser.is_admin;
    document.getElementById("adminSectionLabel").style.display = showAdmin ? "block" : "none";
    document.getElementById("adminSectionCard").style.display = showAdmin ? "block" : "none";
}

async function loadAdminPanel(){
    if(!currentUser.is_admin){
        showToast("Admin access required");
        showPage("home");
        return;
    }

    try{
        const stats = await api("/api/admin/stats");
        const statsRow = document.getElementById("adminStatsRow");
        statsRow.innerHTML = `
            <div class="settings-card" style="padding:16px 22px;flex:1;min-width:120px">
                <div style="font-size:22px;font-weight:bold">${stats.users}</div>
                <div style="font-size:12px;color:var(--muted)">Users</div>
            </div>
            <div class="settings-card" style="padding:16px 22px;flex:1;min-width:120px">
                <div style="font-size:22px;font-weight:bold">${stats.posts}</div>
                <div style="font-size:12px;color:var(--muted)">Posts</div>
            </div>
            <div class="settings-card" style="padding:16px 22px;flex:1;min-width:120px">
                <div style="font-size:22px;font-weight:bold;color:#ff2d75">${stats.pending_reports}</div>
                <div style="font-size:12px;color:var(--muted)">Pending reports</div>
            </div>
        `;

        const data = await api("/api/admin/reports");
        const list = document.getElementById("adminReportsList");
        list.innerHTML = "";

        if(data.reports.length === 0){
            list.innerHTML = `<div style="color:var(--muted)">No reports yet.</div>`;
            return;
        }

        data.reports.forEach(r=>{
            const row = document.createElement("div");
            row.className = "notification";
            const statusColor = r.status === "resolved" ? "#2ecc71" : "#ff2d75";
            row.innerHTML = `
                <div class="avatar" style="background:var(--bg);color:var(--text);font-size:16px">${r.target_type === "post" ? "🖼" : r.target_type === "user" ? "👤" : "💬"}</div>
                <div class="notification-text">
                    <b>${escapeHtml(r.reporter)}</b> reported ${r.target_type} #${r.target_id}
                    <div style="margin-top:3px">${escapeHtml(r.reason)}</div>
                    <div style="color:${statusColor};font-size:11px;margin-top:4px;text-transform:uppercase">${r.status}</div>
                </div>
                ${r.status === "pending" ? `<button class="edit-btn" onclick="resolveReport(${r.id})">Resolve</button>` : ""}
                ${r.target_type === "post" ? `<button class="edit-btn" style="color:#ff2d75" onclick="adminDeleteReportedPost(${r.target_id}, ${r.id})">Delete post</button>` : ""}
            `;
            list.appendChild(row);
        });
    }catch(e){}
}

async function resolveReport(reportId){
    try{
        await api(`/api/admin/reports/${reportId}/resolve`, { method:"POST" });
        showToast("Report resolved");
        await loadAdminPanel();
    }catch(e){}
}

async function adminDeleteReportedPost(postId, reportId){
    if(!confirm("Delete this post permanently?")) return;
    try{
        await api(`/api/posts/${postId}`, { method:"DELETE" });
        await api(`/api/admin/reports/${reportId}/resolve`, { method:"POST" });
        showToast("Post deleted and report resolved");
        await loadAdminPanel();
        await loadFeed();
        await loadExplore();
    }catch(e){}
}

async function openSavedPosts(){
    try{
        const data = await api("/api/saved");
        const box = document.getElementById("userListBody");
        document.getElementById("userListTitle").textContent = "Saved posts";
        box.innerHTML = "";
        if(data.posts.length === 0){
            box.innerHTML = `<div style="color:var(--muted)">No saved posts yet.</div>`;
        }
        data.posts.forEach(p=>{
            const row = document.createElement("div");
            row.className = "suggestion";
            row.innerHTML = `
                <div class="user-info" style="cursor:pointer" onclick="closeUserListModal();viewUserProfile('${p.username}')">
                    <img src="${p.media_url}" style="width:44px;height:44px;object-fit:cover;border-radius:8px">
                    <div>
                        <b style="font-size:13px">@${escapeHtml(p.username)}</b>
                        <div style="font-size:12px;color:var(--muted)">${escapeHtml((p.caption||"").slice(0,30))}</div>
                    </div>
                </div>
            `;
            box.appendChild(row);
        });
        document.getElementById("userListModal").classList.add("show");
    }catch(e){}
}

async function openCloseFriends(){
    try{
        const [friendsData, followingData] = await Promise.all([
            api("/api/close-friends"),
            api(`/api/users/${currentUser.username}/following`)
        ]);
        const friendIds = new Set(friendsData.users.map(u=>u.id));
        const box = document.getElementById("userListBody");
        document.getElementById("userListTitle").textContent = "Close Friends";
        box.innerHTML = "";
        if(followingData.users.length === 0){
            box.innerHTML = `<div style="color:var(--muted)">Follow people to add them here.</div>`;
        }
        followingData.users.forEach(u=>{
            const avatar = u.avatar || `https://i.pravatar.cc/100?u=${u.username}`;
            const isFriend = friendIds.has(u.id);
            const row = document.createElement("div");
            row.className = "suggestion";
            row.innerHTML = `
                <div class="user-info">
                    <div class="avatar"><img src="${avatar}"></div>
                    <div class="user-name">${escapeHtml(u.username)}</div>
                </div>
                <button class="follow-btn" id="cf-${u.id}">${isFriend ? "Remove" : "Add"}</button>
            `;
            row.querySelector("button").onclick = async ()=>{
                const data = await api(`/api/close-friends/${u.id}`, { method:"POST" });
                document.getElementById(`cf-${u.id}`).textContent = data.added ? "Remove" : "Add";
            };
            box.appendChild(row);
        });
        document.getElementById("userListModal").classList.add("show");
    }catch(e){}
}

async function openBlockedList(){
    try{
        const data = await api("/api/blocked");
        const box = document.getElementById("userListBody");
        document.getElementById("userListTitle").textContent = "Blocked accounts";
        box.innerHTML = "";
        if(data.users.length === 0){
            box.innerHTML = `<div style="color:var(--muted)">No blocked accounts.</div>`;
        }
        data.users.forEach(u=>{
            const avatar = u.avatar || `https://i.pravatar.cc/100?u=${u.username}`;
            const row = document.createElement("div");
            row.className = "suggestion";
            row.innerHTML = `
                <div class="user-info">
                    <div class="avatar"><img src="${avatar}"></div>
                    <div class="user-name">${escapeHtml(u.username)}</div>
                </div>
                <button class="follow-btn" onclick="unblockUser(${u.id})">Unblock</button>
            `;
            box.appendChild(row);
        });
        document.getElementById("userListModal").classList.add("show");
    }catch(e){}
}

async function unblockUser(id){
    await api(`/api/blocked/${id}`, { method:"POST" });
    await openBlockedList();
}

async function blockUserFromProfile(id){
    try{
        const data = await api(`/api/blocked/${id}`, { method:"POST" });
        showToast(data.blocked ? "User blocked" : "User unblocked");
        closeLightbox();
        await loadProfile();
    }catch(e){}
}

function promptBlockUser(id, username){
    const box = document.getElementById("postOptionsBody");
    box.innerHTML = "";

    const block = document.createElement("button");
    block.className = "edit-btn";
    block.style.cssText = "width:100%;color:#ff2d75;margin-bottom:8px";
    block.textContent = "Block user";
    block.onclick = ()=>{
        document.getElementById("postOptionsModal").classList.remove("show");
        if(confirm(`Block @${username}? They won't be able to message you or follow you.`)){
            blockUserFromProfile(id);
        }
    };
    box.appendChild(block);

    const report = document.createElement("button");
    report.className = "edit-btn";
    report.style.cssText = "width:100%;color:#ff2d75;margin-bottom:8px";
    report.textContent = "Report user";
    report.onclick = ()=>{
        document.getElementById("postOptionsModal").classList.remove("show");
        const reason = prompt(`Why are you reporting @${username}?`);
        if(!reason || !reason.trim()) return;
        api("/api/report", {
            method:"POST",
            headers:{ "Content-Type":"application/json" },
            body:JSON.stringify({ target_type:"user", target_id:id, reason: reason.trim() })
        }).then(()=>{ showToast("Report submitted."); }).catch(()=>{});
    };
    box.appendChild(report);

    const cancel = document.createElement("button");
    cancel.className = "edit-btn";
    cancel.style.width = "100%";
    cancel.textContent = "Cancel";
    cancel.onclick = ()=>{ document.getElementById("postOptionsModal").classList.remove("show"); };
    box.appendChild(cancel);

    document.getElementById("postOptionsModal").classList.add("show");
}

async function openMutedList(){
    try{
        const data = await api("/api/muted");
        const box = document.getElementById("userListBody");
        document.getElementById("userListTitle").textContent = "Muted accounts";
        box.innerHTML = "";
        if(data.users.length === 0){
            box.innerHTML = `<div style="color:var(--muted)">No muted accounts.</div>`;
        }
        data.users.forEach(u=>{
            const avatar = u.avatar || `https://i.pravatar.cc/100?u=${u.username}`;
            const row = document.createElement("div");
            row.className = "suggestion";
            row.innerHTML = `
                <div class="user-info">
                    <div class="avatar"><img src="${avatar}"></div>
                    <div class="user-name">${escapeHtml(u.username)}</div>
                </div>
                <button class="follow-btn" onclick="unmuteUser(${u.id})">Unmute</button>
            `;
            box.appendChild(row);
        });
        document.getElementById("userListModal").classList.add("show");
    }catch(e){}
}

async function unmuteUser(id){
    await api(`/api/muted/${id}`, { method:"POST" });
    await openMutedList();
}

function toggleDarkMode(){
    document.body.classList.toggle("dark");
    const active = document.body.classList.contains("dark");
    localStorage.setItem("connectx_dark", active ? "yes" : "no");
    const toggle = document.getElementById("darkToggle");
    if(toggle){ toggle.classList.toggle("active", active); }
    const menuToggle = document.getElementById("profileMenuDarkToggle");
    if(menuToggle){ menuToggle.classList.toggle("active", active); }
}

function openProfileMenu(){
    const active = document.body.classList.contains("dark");
    const menuToggle = document.getElementById("profileMenuDarkToggle");
    if(menuToggle){ menuToggle.classList.toggle("active", active); }
    document.getElementById("profileMenuModal").classList.add("show");
}

function closeProfileMenu(){
    document.getElementById("profileMenuModal").classList.remove("show");
}

let searchTimer;
async function searchUsers(){
    const value = document.getElementById("globalSearch").value.trim();
    clearTimeout(searchTimer);
    if(value.length < 2){
        closeSearchResults();
        return;
    }
    searchTimer = setTimeout(async()=>{
        try{
            const data = await api("/api/users/search?q=" + encodeURIComponent(value));
            renderSearchResults(data.users);
        }catch(e){}
    },400);
}

function renderSearchResults(users){
    let box = document.getElementById("searchResults");
    if(!box){
        box = document.createElement("div");
        box.id = "searchResults";
        box.style.cssText = "position:absolute;top:calc(100% + 8px);left:0;right:0;background:var(--card);border:1px solid var(--border);border-radius:12px;max-height:300px;overflow:auto;z-index:200;box-shadow:var(--shadow);";
        document.querySelector(".search-box").appendChild(box);
    }
    box.innerHTML = "";
    if(users.length === 0){
        box.innerHTML = `<div style="padding:12px;color:var(--muted)">No users found</div>`;
        return;
    }
    users.forEach(u=>{
        const avatar = u.avatar || `https://i.pravatar.cc/100?u=${u.username}`;
        const row = document.createElement("div");
        row.className = "chat";
        row.onclick = ()=>{
            closeSearchResults();
            document.getElementById("globalSearch").value = "";
            viewUserProfile(u.username);
        };
        row.innerHTML = `
            <div class="avatar"><img src="${avatar}"></div>
            <div class="chat-name">${escapeHtml(u.username)}</div>
        `;
        box.appendChild(row);
    });
}

function closeSearchResults(){
    const box = document.getElementById("searchResults");
    if(box) box.remove();
}

document.addEventListener("click", function(event){
    const box = document.getElementById("searchResults");
    if(!box) return;
    const searchBox = document.querySelector(".search-box");
    if(searchBox && !searchBox.contains(event.target)){
        closeSearchResults();
    }
});

function showToast(message){
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(()=>{ toast.classList.remove("show"); },2500);
}

function escapeHtml(value){
    return String(value || "")
        .replace(/&/g,"&amp;")
        .replace(/</g,"&lt;")
        .replace(/>/g,"&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g,"&#039;");
}

function formatCaptionHtml(text){
    const escaped = escapeHtml(text);
    return escaped
        .replace(/#(\w+)/g, `<span class="hashtag-link" onclick="openHashtag('$1')">#$1</span>`)
        .replace(/@(\w+)/g, `<span class="mention-link" onclick="viewUserProfile('$1')">@$1</span>`);
}

function openHashtag(tag){
    showPage("explore");
    document.getElementById("exploreSearch").value = "#" + tag;
    searchExplore();
}

document.addEventListener("DOMContentLoaded", async function(){
    if(localStorage.getItem("connectx_dark") === "yes"){
        document.body.classList.add("dark");
        const toggle = document.getElementById("darkToggle");
        if(toggle){ toggle.classList.add("active"); }
    }
    try{
        const data = await api("/api/me");
        if(data.logged_in){
            currentUser = data.user;
            openApp();
            await loadApp();
        }
    }catch(e){}
});

document.addEventListener("keydown", function(event){
    if(event.key === "Enter" && document.activeElement.id === "messageInput"){
        event.preventDefault();
        sendMessage();
    }
});
</script>

</body>
</html>
"""


# ============================================================
# FRONTEND ROUTE
# ============================================================

@app.route("/")
def index():
    return render_template_string(HTML)


# ============================================================
# AUTH API
# ============================================================

@app.route("/api/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}

    full_name = data.get("full_name", "").strip()
    username = data.get("username", "").strip().lower()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not full_name or not username or not email or not password:
        return jsonify({"success": False, "message": "All fields are required."}), 400

    if len(username) < 3:
        return jsonify({"success": False, "message": "Username must contain at least 3 characters."}), 400

    if len(password) < 6:
        return jsonify({"success": False, "message": "Password must contain at least 6 characters."}), 400

    conn = get_db()
    try:
        exists = conn.execute("""
            SELECT id FROM users WHERE username=? OR email=?
        """, (username, email)).fetchone()

        if exists:
            return jsonify({"success": False, "message": "Username or email already exists."}), 409

        cursor = conn.execute("""
            INSERT INTO users (full_name, username, email, password_hash, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (
            full_name, username, email,
            generate_password_hash(password),
            datetime.now().isoformat()
        ))

        user_id = cursor.lastrowid
        conn.commit()

        user = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()

        session["user_id"] = user_id

        return jsonify({
            "success": True,
            "message": "Account created successfully.",
            "user": user_json(user)
        })
    finally:
        conn.close()


@app.route("/api/auth/forgot", methods=["POST"])
def forgot_password():
    data = request.get_json(silent=True) or {}
    identity = data.get("email", "").strip().lower()

    if not identity:
        return jsonify({"success": False, "message": "Enter your username or email."}), 400

    conn = get_db()
    user = conn.execute(
        "SELECT id FROM users WHERE username=? OR email=?", (identity, identity)
    ).fetchone()

    if not user:
        conn.close()
        return jsonify({"success": False, "message": "No account found with that username or email."}), 404

    token = uuid.uuid4().hex[:8].upper()
    expires = datetime.now() + timedelta(minutes=15)

    conn.execute("""
        INSERT INTO reset_tokens (user_id, token, expires_at, created_at)
        VALUES (?, ?, ?, ?)
    """, (user["id"], token, expires.isoformat(), datetime.now().isoformat()))
    conn.commit()
    conn.close()

    # NOTE: This is a demo app with no email server configured, so the reset
    # code is returned directly instead of being emailed. In a real deployment
    # this token would be sent to the user's email, never returned in the API response.
    return jsonify({
        "success": True,
        "message": "Reset code generated (demo mode — no email server configured).",
        "demo_token": token
    })


@app.route("/api/auth/reset", methods=["POST"])
def reset_password():
    data = request.get_json(silent=True) or {}
    token = data.get("token", "").strip().upper()
    new_password = data.get("password", "")

    if not token or len(new_password) < 6:
        return jsonify({"success": False, "message": "Enter the code and a password of at least 6 characters."}), 400

    conn = get_db()
    row = conn.execute("""
        SELECT id, user_id, expires_at FROM reset_tokens
        WHERE token=? AND used=0
        ORDER BY id DESC LIMIT 1
    """, (token,)).fetchone()

    if not row:
        conn.close()
        return jsonify({"success": False, "message": "Invalid or already-used code."}), 400

    if datetime.now() > datetime.fromisoformat(row["expires_at"]):
        conn.close()
        return jsonify({"success": False, "message": "This code has expired. Request a new one."}), 400

    conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), row["user_id"]))
    conn.execute("UPDATE reset_tokens SET used=1 WHERE id=?", (row["id"],))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Password reset successfully. You can now log in."})


@app.route("/api/login", methods=["POST"])
def login_api():
    data = request.get_json(silent=True) or {}

    identity = data.get("username", "").strip().lower()
    password = data.get("password", "")

    if not identity or not password:
        return jsonify({"success": False, "message": "Login details are required."}), 400

    conn = get_db()
    user = conn.execute("""
        SELECT * FROM users WHERE username=? OR email=?
    """, (identity, identity)).fetchone()
    conn.close()

    if not user:
        return jsonify({"success": False, "message": "Invalid username/email or password."}), 401

    if not check_password_hash(user["password_hash"], password):
        return jsonify({"success": False, "message": "Invalid username/email or password."}), 401

    session["user_id"] = user["id"]

    return jsonify({
        "success": True,
        "message": "Login successful.",
        "user": user_json(user)
    })


@app.route("/api/logout", methods=["POST"])
def logout_api():
    session.clear()
    return jsonify({"success": True, "message": "Logged out."})


@app.route("/api/me")
def me():
    user = current_user()
    if not user:
        return jsonify({"success": True, "logged_in": False})
    return jsonify({"success": True, "logged_in": True, "user": user_json(user)})


# ============================================================
# POSTS
# ============================================================

@app.route("/api/posts/hashtag/<tag>")
def posts_by_hashtag(tag):
    user = current_user()
    current_id = user["id"] if user else 0
    conn = get_db()

    rows = conn.execute("""
        SELECT p.id, p.media_url, p.media_type, p.caption, u.username
        FROM posts p JOIN users u ON u.id = p.user_id
        WHERE p.caption LIKE ?
        ORDER BY p.id DESC
    """, (f"%#{tag}%",)).fetchall()
    conn.close()

    return jsonify({
        "success": True,
        "posts": [
            {"id": r["id"], "media_url": r["media_url"], "media_type": r["media_type"],
             "caption": r["caption"], "username": r["username"]}
            for r in rows
        ]
    })


@app.route("/api/posts", methods=["GET"])
def get_posts():
    user = current_user()
    current_id = user["id"] if user else 0

    conn = get_db()
    rows = conn.execute("""
        SELECT
            p.id, p.user_id, p.media_url, p.media_type, p.caption, p.music_url, p.music_name,
            p.filter_name, p.overlay_text, p.views, p.location, p.created_at,
            u.username, u.full_name, u.avatar, u.is_verified,
            (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) AS likes,
            (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) AS comments_count,
            EXISTS(SELECT 1 FROM likes l2 WHERE l2.post_id=p.id AND l2.user_id=?) AS liked,
            EXISTS(SELECT 1 FROM saved_posts s WHERE s.post_id=p.id AND s.user_id=?) AS saved
        FROM posts p
        JOIN users u ON u.id=p.user_id
        WHERE p.user_id NOT IN (SELECT muted_id FROM muted_users WHERE user_id=?)
        ORDER BY p.id DESC
    """, (current_id, current_id, current_id)).fetchall()

    post_ids = [row["id"] for row in rows]
    extra_media_map = {}
    if post_ids:
        placeholders = ",".join("?" * len(post_ids))
        media_rows = conn.execute(f"""
            SELECT post_id, media_url, media_type FROM post_media
            WHERE post_id IN ({placeholders})
            ORDER BY post_id, position
        """, post_ids).fetchall()
        for mr in media_rows:
            extra_media_map.setdefault(mr["post_id"], []).append(
                {"media_url": mr["media_url"], "media_type": mr["media_type"]}
            )

    conn.close()

    posts = []
    for row in rows:
        posts.append({
            "id": row["id"],
            "user_id": row["user_id"],
            "media_url": row["media_url"],
            "media_type": row["media_type"],
            "media_items": extra_media_map.get(row["id"], []),
            "caption": row["caption"],
            "music_url": row["music_url"],
            "music_name": row["music_name"],
            "filter_name": row["filter_name"],
            "overlay_text": row["overlay_text"],
            "views": row["views"] if row["views"] is not None else 0,
            "location": row["location"] if "location" in row.keys() and row["location"] else "",
            "created_at": row["created_at"],
            "username": row["username"],
            "full_name": row["full_name"],
            "avatar": row["avatar"],
            "is_verified": bool(row["is_verified"]) if row["is_verified"] is not None else False,
            "likes": row["likes"],
            "comments_count": row["comments_count"],
            "liked": bool(row["liked"]),
            "saved": bool(row["saved"])
        })

    return jsonify({"success": True, "posts": posts})


@app.route("/api/posts", methods=["POST"])
def create_post():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    files = request.files.getlist("files") or ([request.files.get("file")] if request.files.get("file") else [])
    music_file = request.files.get("music")
    caption = request.form.get("caption", "").strip()
    filter_name = request.form.get("filter_name", "").strip()
    overlay_text = request.form.get("overlay_text", "").strip()[:100]
    location = request.form.get("location", "").strip()[:60]

    ALLOWED_FILTERS = {"", "grayscale", "sepia", "warm", "cool", "contrast", "fade"}
    if filter_name not in ALLOWED_FILTERS:
        filter_name = ""

    files = [f for f in files if f and f.filename][:10]

    if not files:
        return jsonify({"success": False, "message": "Please select a file."}), 400

    for f in files:
        if not allowed_file(f.filename):
            return jsonify({"success": False, "message": "This file type is not allowed."}), 400

    saved_media = []
    for f in files:
        extension = f.filename.rsplit(".", 1)[1].lower()
        filename = uuid.uuid4().hex + "." + extension
        safe_name = secure_filename(filename)
        f.save(os.path.join(UPLOAD_DIR, safe_name))
        m_type = "video" if f.mimetype.startswith("video/") else "image"
        saved_media.append(("/uploads/" + safe_name, m_type))

    media_url, media_type = saved_media[0]

    music_url = ""
    music_name = ""

    if music_file and music_file.filename:
        allowed_audio = {"mp3", "wav", "ogg", "m4a"}
        m_ext = music_file.filename.rsplit(".", 1)[-1].lower() if "." in music_file.filename else ""
        if m_ext in allowed_audio:
            m_filename = uuid.uuid4().hex + "." + m_ext
            m_safe = secure_filename(m_filename)
            music_file.save(os.path.join(UPLOAD_DIR, m_safe))
            music_url = "/uploads/" + m_safe
            music_name = music_file.filename.rsplit(".", 1)[0][:60]

    conn = get_db()
    cursor = conn.execute("""
        INSERT INTO posts (user_id, media_url, media_type, caption, music_url, music_name, filter_name, overlay_text, location, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (user["id"], media_url, media_type, caption, music_url, music_name, filter_name, overlay_text, location, datetime.now().isoformat()))
    new_post_id = cursor.lastrowid

    if len(saved_media) > 1:
        for pos, (m_url, m_type) in enumerate(saved_media):
            conn.execute("""
                INSERT INTO post_media (post_id, media_url, media_type, position)
                VALUES (?, ?, ?, ?)
            """, (new_post_id, m_url, m_type, pos))

    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Post created successfully."})


@app.route("/api/posts/<int:post_id>", methods=["PUT"])
def edit_post(post_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    data = request.get_json(silent=True) or {}
    caption = data.get("caption", None)
    overlay_text = data.get("overlay_text", None)

    conn = get_db()
    post = conn.execute("SELECT user_id FROM posts WHERE id=?", (post_id,)).fetchone()

    if not post:
        conn.close()
        return jsonify({"success": False, "message": "Post not found."}), 404

    if post["user_id"] != user["id"]:
        conn.close()
        return jsonify({"success": False, "message": "You can only edit your own posts."}), 403

    if caption is not None:
        conn.execute("UPDATE posts SET caption=? WHERE id=?", (caption.strip(), post_id))
    if overlay_text is not None:
        conn.execute("UPDATE posts SET overlay_text=? WHERE id=?", (overlay_text.strip()[:100], post_id))

    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Post updated."})


@app.route("/api/posts/<int:post_id>", methods=["DELETE"])
def delete_post(post_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()

    post = conn.execute("SELECT user_id FROM posts WHERE id=?", (post_id,)).fetchone()

    if not post:
        conn.close()
        return jsonify({"success": False, "message": "Post not found."}), 404

    if post["user_id"] != user["id"] and not user["is_admin"]:
        conn.close()
        return jsonify({"success": False, "message": "You can only delete your own posts."}), 403

    conn.execute("DELETE FROM posts WHERE id=?", (post_id,))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Post deleted."})


# ============================================================
# REPORTS & ADMIN
# ============================================================

@app.route("/api/report", methods=["POST"])
def submit_report():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    data = request.get_json(silent=True) or {}
    target_type = data.get("target_type")
    target_id = data.get("target_id")
    reason = data.get("reason", "").strip()

    if target_type not in ("post", "comment", "user") or not target_id or not reason:
        return jsonify({"success": False, "message": "Invalid report."}), 400

    conn = get_db()
    conn.execute("""
        INSERT INTO reports (reporter_id, target_type, target_id, reason, created_at)
        VALUES (?, ?, ?, ?, ?)
    """, (user["id"], target_type, target_id, reason, datetime.now().isoformat()))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Thanks, we received your report."})


def require_admin():
    user = current_user()
    if not user or not user["is_admin"]:
        return jsonify({"success": False, "message": "Admin access required."}), 403
    return None


@app.route("/api/admin/reports")
def admin_list_reports():
    auth = login_required()
    if auth:
        return auth
    forbidden = require_admin()
    if forbidden:
        return forbidden

    conn = get_db()
    rows = conn.execute("""
        SELECT r.id, r.target_type, r.target_id, r.reason, r.status, r.created_at, u.username AS reporter
        FROM reports r JOIN users u ON u.id = r.reporter_id
        ORDER BY r.id DESC
    """).fetchall()
    conn.close()

    return jsonify({
        "success": True,
        "reports": [
            {
                "id": r["id"], "target_type": r["target_type"], "target_id": r["target_id"],
                "reason": r["reason"], "status": r["status"], "created_at": r["created_at"],
                "reporter": r["reporter"]
            }
            for r in rows
        ]
    })


@app.route("/api/admin/reports/<int:report_id>/resolve", methods=["POST"])
def admin_resolve_report(report_id):
    auth = login_required()
    if auth:
        return auth
    forbidden = require_admin()
    if forbidden:
        return forbidden

    conn = get_db()
    conn.execute("UPDATE reports SET status='resolved' WHERE id=?", (report_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})


@app.route("/api/admin/stats")
def admin_stats():
    auth = login_required()
    if auth:
        return auth
    forbidden = require_admin()
    if forbidden:
        return forbidden

    conn = get_db()
    users_count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    posts_count = conn.execute("SELECT COUNT(*) FROM posts").fetchone()[0]
    pending_reports = conn.execute("SELECT COUNT(*) FROM reports WHERE status='pending'").fetchone()[0]
    conn.close()

    return jsonify({
        "success": True,
        "users": users_count,
        "posts": posts_count,
        "pending_reports": pending_reports
    })


@app.route("/api/posts/<int:post_id>/view", methods=["POST"])
def add_view(post_id):
    conn = get_db()
    conn.execute("UPDATE posts SET views = views + 1 WHERE id=?", (post_id,))
    conn.commit()
    row = conn.execute("SELECT views FROM posts WHERE id=?", (post_id,)).fetchone()
    conn.close()
    return jsonify({"success": True, "views": row["views"] if row else 0})


# ============================================================
# LIKE
# ============================================================

@app.route("/api/posts/<int:post_id>/like", methods=["POST"])
def like_post(post_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()

    exists = conn.execute("""
        SELECT id FROM likes WHERE user_id=? AND post_id=?
    """, (user["id"], post_id)).fetchone()

    if exists:
        conn.execute("""
            DELETE FROM likes WHERE user_id=? AND post_id=?
        """, (user["id"], post_id))
        liked = False
    else:
        conn.execute("""
            INSERT INTO likes (user_id, post_id, created_at)
            VALUES (?, ?, ?)
        """, (user["id"], post_id, datetime.now().isoformat()))
        liked = True

        post = conn.execute("SELECT user_id FROM posts WHERE id=?", (post_id,)).fetchone()

        if post and post["user_id"] != user["id"]:
            conn.execute("""
                INSERT INTO notifications (user_id, actor_id, notification_type, text, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (
                post["user_id"], user["id"], "like",
                user["username"] + " liked your post",
                datetime.now().isoformat()
            ))

    conn.commit()

    count = conn.execute("SELECT COUNT(*) FROM likes WHERE post_id=?", (post_id,)).fetchone()[0]
    conn.close()

    return jsonify({"success": True, "liked": liked, "likes": count})


# ============================================================
# SAVE
# ============================================================

@app.route("/api/posts/<int:post_id>/save", methods=["POST"])
def save_post(post_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()

    exists = conn.execute("""
        SELECT id FROM saved_posts WHERE user_id=? AND post_id=?
    """, (user["id"], post_id)).fetchone()

    if exists:
        conn.execute("""
            DELETE FROM saved_posts WHERE user_id=? AND post_id=?
        """, (user["id"], post_id))
        saved = False
    else:
        conn.execute("""
            INSERT INTO saved_posts (user_id, post_id, created_at)
            VALUES (?, ?, ?)
        """, (user["id"], post_id, datetime.now().isoformat()))
        saved = True

    conn.commit()
    conn.close()

    return jsonify({"success": True, "saved": saved})


# ============================================================
# COMMENTS
# ============================================================

@app.route("/api/posts/<int:post_id>/comments", methods=["POST"])
def add_comment_api(post_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    data = request.get_json(silent=True) or {}
    comment = data.get("comment", "").strip()

    if not comment:
        return jsonify({"success": False, "message": "Comment cannot be empty."}), 400

    conn = get_db()
    post = conn.execute("SELECT user_id FROM posts WHERE id=?", (post_id,)).fetchone()

    if not post:
        conn.close()
        return jsonify({"success": False, "message": "Post not found."}), 404

    owner = conn.execute("SELECT comments_enabled FROM users WHERE id=?", (post["user_id"],)).fetchone()
    if owner and owner["comments_enabled"] == 0:
        conn.close()
        return jsonify({"success": False, "message": "Comments are turned off for this post."}), 403

    conn.execute("""
        INSERT INTO comments (user_id, post_id, comment, created_at)
        VALUES (?, ?, ?, ?)
    """, (user["id"], post_id, comment, datetime.now().isoformat()))

    if post["user_id"] != user["id"]:
        conn.execute("""
            INSERT INTO notifications (user_id, actor_id, notification_type, text, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (
            post["user_id"], user["id"], "comment",
            user["username"] + " commented on your post",
            datetime.now().isoformat()
        ))

    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Comment added."})


@app.route("/api/posts/<int:post_id>/comments", methods=["GET"])
def list_comments(post_id):
    viewer = current_user()
    conn = get_db()

    post = conn.execute("SELECT user_id FROM posts WHERE id=?", (post_id,)).fetchone()
    if not post:
        conn.close()
        return jsonify({"success": False, "message": "Post not found."}), 404

    rows = conn.execute("""
        SELECT c.id, c.comment, c.created_at, c.user_id, u.username, u.avatar
        FROM comments c
        JOIN users u ON u.id = c.user_id
        WHERE c.post_id=?
        ORDER BY c.id ASC
    """, (post_id,)).fetchall()
    conn.close()

    viewer_id = viewer["id"] if viewer else 0

    return jsonify({
        "success": True,
        "comments": [
            {
                "id": r["id"],
                "comment": r["comment"],
                "username": r["username"],
                "avatar": r["avatar"],
                "can_delete": bool(viewer and (r["user_id"] == viewer_id or post["user_id"] == viewer_id))
            }
            for r in rows
        ]
    })


@app.route("/api/comments/<int:comment_id>", methods=["DELETE"])
def delete_comment(comment_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()

    row = conn.execute("""
        SELECT c.user_id AS commenter_id, p.user_id AS post_owner_id
        FROM comments c JOIN posts p ON p.id = c.post_id
        WHERE c.id=?
    """, (comment_id,)).fetchone()

    if not row:
        conn.close()
        return jsonify({"success": False, "message": "Comment not found."}), 404

    if user["id"] not in (row["commenter_id"], row["post_owner_id"]):
        conn.close()
        return jsonify({"success": False, "message": "You can't delete this comment."}), 403

    conn.execute("DELETE FROM comments WHERE id=?", (comment_id,))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Comment deleted."})


# ============================================================
# FOLLOW
# ============================================================

@app.route("/api/users/<int:user_id>/follow", methods=["POST"])
def follow_user(user_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()

    if user["id"] == user_id:
        return jsonify({"success": False, "message": "You cannot follow yourself."}), 400

    conn = get_db()
    target = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()

    if not target:
        conn.close()
        return jsonify({"success": False, "message": "User not found."}), 404

    exists = conn.execute("""
        SELECT id FROM follows WHERE follower_id=? AND following_id=?
    """, (user["id"], user_id)).fetchone()

    if exists:
        conn.execute("""
            DELETE FROM follows WHERE follower_id=? AND following_id=?
        """, (user["id"], user_id))
        following = False
    else:
        conn.execute("""
            INSERT INTO follows (follower_id, following_id, created_at)
            VALUES (?, ?, ?)
        """, (user["id"], user_id, datetime.now().isoformat()))
        following = True

        conn.execute("""
            INSERT INTO notifications (user_id, actor_id, notification_type, text, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (
            user_id, user["id"], "follow",
            user["username"] + " started following you",
            datetime.now().isoformat()
        ))

    conn.commit()
    conn.close()

    return jsonify({"success": True, "following": following})


# ============================================================
# USER SUGGESTIONS
# ============================================================

@app.route("/api/users/suggestions")
def suggestions():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()

    rows = conn.execute("""
        SELECT u.id, u.username, u.full_name, u.avatar,
            EXISTS(SELECT 1 FROM follows f WHERE f.follower_id=? AND f.following_id=u.id) AS following
        FROM users u
        WHERE u.id != ?
        ORDER BY u.id DESC
        LIMIT 10
    """, (user["id"], user["id"])).fetchall()

    conn.close()

    return jsonify({
        "success": True,
        "users": [
            {
                "id": row["id"],
                "username": row["username"],
                "full_name": row["full_name"],
                "avatar": row["avatar"],
                "following": bool(row["following"])
            }
            for row in rows
        ]
    })


# ============================================================
# SEARCH
# ============================================================

@app.route("/api/users/search")
def search():
    auth = login_required()
    if auth:
        return auth

    q = request.args.get("q", "").strip()

    if len(q) < 2:
        return jsonify({"success": True, "users": []})

    conn = get_db()
    rows = conn.execute("""
        SELECT id, username, full_name, avatar
        FROM users
        WHERE username LIKE ? OR full_name LIKE ?
        ORDER BY username
        LIMIT 20
    """, ("%" + q + "%", "%" + q + "%")).fetchall()
    conn.close()

    return jsonify({
        "success": True,
        "users": [
            {
                "id": row["id"],
                "username": row["username"],
                "full_name": row["full_name"],
                "avatar": row["avatar"]
            }
            for row in rows
        ]
    })


# ============================================================
# PROFILE
# ============================================================

@app.route("/api/users/<username>")
def profile(username):
    viewer = current_user()
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE username=?", (username.lower(),)).fetchone()

    if not user:
        conn.close()
        return jsonify({"success": False, "message": "User not found."}), 404

    posts_count = conn.execute("SELECT COUNT(*) FROM posts WHERE user_id=?", (user["id"],)).fetchone()[0]
    followers = conn.execute("SELECT COUNT(*) FROM follows WHERE following_id=?", (user["id"],)).fetchone()[0]
    following = conn.execute("SELECT COUNT(*) FROM follows WHERE follower_id=?", (user["id"],)).fetchone()[0]

    is_following = False
    if viewer:
        is_following = bool(conn.execute("""
            SELECT 1 FROM follows WHERE follower_id=? AND following_id=?
        """, (viewer["id"], user["id"])).fetchone())

    posts = conn.execute("""
        SELECT id, media_url, media_type, caption
        FROM posts
        WHERE user_id=?
        ORDER BY id DESC
    """, (user["id"],)).fetchall()

    conn.close()

    return jsonify({
        "success": True,
        "user": {
            "id": user["id"],
            "username": user["username"],
            "full_name": user["full_name"],
            "email": user["email"],
            "bio": user["bio"],
            "avatar": user["avatar"],
            "profile_music_url": user["profile_music_url"] if "profile_music_url" in user.keys() else "",
            "profile_music_name": user["profile_music_name"] if "profile_music_name" in user.keys() else "",
            "is_private": bool(user["is_private"]),
            "is_verified": bool(user["is_verified"]) if "is_verified" in user.keys() and user["is_verified"] is not None else False,
            "posts": posts_count,
            "followers": followers,
            "following": following,
            "is_following": is_following,
            "is_me": bool(viewer and viewer["id"] == user["id"])
        },
        "posts": [
            {
                "id": p["id"],
                "media_url": p["media_url"],
                "media_type": p["media_type"],
                "caption": p["caption"]
            }
            for p in posts
        ]
    })


@app.route("/api/users/<username>/following")
def get_following_list(username):
    conn = get_db()
    target = conn.execute("SELECT id FROM users WHERE username=?", (username.lower(),)).fetchone()
    if not target:
        conn.close()
        return jsonify({"success": False, "message": "User not found."}), 404

    rows = conn.execute("""
        SELECT u.id, u.username, u.full_name, u.avatar
        FROM follows f
        JOIN users u ON u.id = f.following_id
        WHERE f.follower_id=?
        ORDER BY u.username
    """, (target["id"],)).fetchall()
    conn.close()

    return jsonify({
        "success": True,
        "users": [
            {"id": r["id"], "username": r["username"], "full_name": r["full_name"], "avatar": r["avatar"]}
            for r in rows
        ]
    })


@app.route("/api/users/<username>/followers")
def get_followers_list(username):
    conn = get_db()
    target = conn.execute("SELECT id FROM users WHERE username=?", (username.lower(),)).fetchone()
    if not target:
        conn.close()
        return jsonify({"success": False, "message": "User not found."}), 404

    rows = conn.execute("""
        SELECT u.id, u.username, u.full_name, u.avatar
        FROM follows f
        JOIN users u ON u.id = f.follower_id
        WHERE f.following_id=?
        ORDER BY u.username
    """, (target["id"],)).fetchall()
    conn.close()

    return jsonify({
        "success": True,
        "users": [
            {"id": r["id"], "username": r["username"], "full_name": r["full_name"], "avatar": r["avatar"]}
            for r in rows
        ]
    })


@app.route("/api/profile/avatar", methods=["POST"])
def update_avatar():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    file = request.files.get("file")

    if not file or file.filename == "":
        return jsonify({"success": False, "message": "Please select an image."}), 400

    if not allowed_file(file.filename):
        return jsonify({"success": False, "message": "This file type is not allowed."}), 400

    extension = file.filename.rsplit(".", 1)[1].lower()
    filename = uuid.uuid4().hex + "." + extension
    safe_name = secure_filename(filename)
    path = os.path.join(UPLOAD_DIR, safe_name)
    file.save(path)

    avatar_url = "/uploads/" + safe_name

    conn = get_db()
    conn.execute("UPDATE users SET avatar=? WHERE id=?", (avatar_url, user["id"]))
    conn.commit()
    updated = conn.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
    conn.close()

    return jsonify({"success": True, "user": user_json(updated)})


@app.route("/api/profile/music", methods=["POST"])
def update_profile_music():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    music_file = request.files.get("music")

    if not music_file or music_file.filename == "":
        return jsonify({"success": False, "message": "Please select an audio file."}), 400

    allowed_audio = {"mp3", "wav", "ogg", "m4a"}
    m_ext = music_file.filename.rsplit(".", 1)[-1].lower() if "." in music_file.filename else ""

    if m_ext not in allowed_audio:
        return jsonify({"success": False, "message": "Only mp3, wav, ogg or m4a files are allowed."}), 400

    m_filename = uuid.uuid4().hex + "." + m_ext
    m_safe = secure_filename(m_filename)
    music_file.save(os.path.join(UPLOAD_DIR, m_safe))

    music_url = "/uploads/" + m_safe
    music_name = music_file.filename.rsplit(".", 1)[0][:60]

    conn = get_db()
    conn.execute(
        "UPDATE users SET profile_music_url=?, profile_music_name=? WHERE id=?",
        (music_url, music_name, user["id"])
    )
    conn.commit()
    updated = conn.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
    conn.close()

    return jsonify({"success": True, "user": user_json(updated)})


@app.route("/api/profile/music", methods=["DELETE"])
def remove_profile_music():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()
    conn.execute(
        "UPDATE users SET profile_music_url='', profile_music_name='' WHERE id=?",
        (user["id"],)
    )
    conn.commit()
    updated = conn.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
    conn.close()

    return jsonify({"success": True, "user": user_json(updated)})


@app.route("/api/profile", methods=["PUT"])
def update_profile():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    data = request.get_json(silent=True) or {}

    full_name = data.get("full_name", user["full_name"]).strip()
    bio = data.get("bio", user["bio"]).strip()

    conn = get_db()
    conn.execute("""
        UPDATE users SET full_name=?, bio=? WHERE id=?
    """, (full_name, bio, user["id"]))
    conn.commit()

    updated = conn.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
    conn.close()

    return jsonify({"success": True, "user": user_json(updated)})


@app.route("/api/profile/privacy", methods=["POST"])
def toggle_privacy():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()

    new_value = 0 if user["is_private"] else 1

    conn.execute("UPDATE users SET is_private=? WHERE id=?", (new_value, user["id"]))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "is_private": bool(new_value)})


@app.route("/api/profile/comments-toggle", methods=["POST"])
def toggle_comments():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()
    current_val = conn.execute("SELECT comments_enabled FROM users WHERE id=?", (user["id"],)).fetchone()
    new_value = 0 if (current_val and current_val["comments_enabled"]) else 1
    conn.execute("UPDATE users SET comments_enabled=? WHERE id=?", (new_value, user["id"]))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "comments_enabled": bool(new_value)})


# ============================================================
# SAVED POSTS
# ============================================================

@app.route("/api/saved")
def get_saved_posts():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()
    rows = conn.execute("""
        SELECT p.id, p.media_url, p.media_type, p.caption, u.username
        FROM saved_posts s
        JOIN posts p ON p.id = s.post_id
        JOIN users u ON u.id = p.user_id
        WHERE s.user_id=?
        ORDER BY s.id DESC
    """, (user["id"],)).fetchall()
    conn.close()

    return jsonify({
        "success": True,
        "posts": [
            {"id": r["id"], "media_url": r["media_url"], "media_type": r["media_type"],
             "caption": r["caption"], "username": r["username"]}
            for r in rows
        ]
    })


# ============================================================
# CLOSE FRIENDS
# ============================================================

@app.route("/api/close-friends")
def get_close_friends():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()
    rows = conn.execute("""
        SELECT u.id, u.username, u.avatar
        FROM close_friends cf JOIN users u ON u.id = cf.friend_id
        WHERE cf.user_id=?
        ORDER BY u.username
    """, (user["id"],)).fetchall()
    conn.close()

    return jsonify({"success": True, "users": [{"id": r["id"], "username": r["username"], "avatar": r["avatar"]} for r in rows]})


@app.route("/api/close-friends/<int:friend_id>", methods=["POST"])
def toggle_close_friend(friend_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()
    exists = conn.execute("SELECT id FROM close_friends WHERE user_id=? AND friend_id=?", (user["id"], friend_id)).fetchone()

    if exists:
        conn.execute("DELETE FROM close_friends WHERE user_id=? AND friend_id=?", (user["id"], friend_id))
        added = False
    else:
        conn.execute("INSERT INTO close_friends (user_id, friend_id, created_at) VALUES (?, ?, ?)",
                     (user["id"], friend_id, datetime.now().isoformat()))
        added = True

    conn.commit()
    conn.close()
    return jsonify({"success": True, "added": added})


# ============================================================
# BLOCKED USERS
# ============================================================

@app.route("/api/blocked")
def get_blocked():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()
    rows = conn.execute("""
        SELECT u.id, u.username, u.avatar
        FROM blocked_users b JOIN users u ON u.id = b.blocked_id
        WHERE b.user_id=?
        ORDER BY u.username
    """, (user["id"],)).fetchall()
    conn.close()

    return jsonify({"success": True, "users": [{"id": r["id"], "username": r["username"], "avatar": r["avatar"]} for r in rows]})


@app.route("/api/blocked/<int:blocked_id>", methods=["POST"])
def toggle_block(blocked_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    if user["id"] == blocked_id:
        return jsonify({"success": False, "message": "You can't block yourself."}), 400

    conn = get_db()
    exists = conn.execute("SELECT id FROM blocked_users WHERE user_id=? AND blocked_id=?", (user["id"], blocked_id)).fetchone()

    if exists:
        conn.execute("DELETE FROM blocked_users WHERE user_id=? AND blocked_id=?", (user["id"], blocked_id))
        blocked = False
    else:
        conn.execute("INSERT INTO blocked_users (user_id, blocked_id, created_at) VALUES (?, ?, ?)",
                     (user["id"], blocked_id, datetime.now().isoformat()))
        blocked = True
        conn.execute("DELETE FROM follows WHERE (follower_id=? AND following_id=?) OR (follower_id=? AND following_id=?)",
                     (user["id"], blocked_id, blocked_id, user["id"]))

    conn.commit()
    conn.close()
    return jsonify({"success": True, "blocked": blocked})


# ============================================================
# MUTED USERS
# ============================================================

@app.route("/api/muted")
def get_muted():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()
    rows = conn.execute("""
        SELECT u.id, u.username, u.avatar
        FROM muted_users m JOIN users u ON u.id = m.muted_id
        WHERE m.user_id=?
        ORDER BY u.username
    """, (user["id"],)).fetchall()
    conn.close()

    return jsonify({"success": True, "users": [{"id": r["id"], "username": r["username"], "avatar": r["avatar"]} for r in rows]})


@app.route("/api/muted/<int:muted_id>", methods=["POST"])
def toggle_mute(muted_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()
    exists = conn.execute("SELECT id FROM muted_users WHERE user_id=? AND muted_id=?", (user["id"], muted_id)).fetchone()

    if exists:
        conn.execute("DELETE FROM muted_users WHERE user_id=? AND muted_id=?", (user["id"], muted_id))
        muted = False
    else:
        conn.execute("INSERT INTO muted_users (user_id, muted_id, created_at) VALUES (?, ?, ?)",
                     (user["id"], muted_id, datetime.now().isoformat()))
        muted = True

    conn.commit()
    conn.close()
    return jsonify({"success": True, "muted": muted})


# ============================================================
# CHATS
# ============================================================

@app.route("/api/users/chats")
def chat_users():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()

    rows = conn.execute("""
        SELECT
            u.id, u.username, u.full_name, u.avatar,
            (
                SELECT m.message FROM messages m
                WHERE (m.sender_id=u.id AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=u.id)
                ORDER BY m.id DESC LIMIT 1
            ) AS last_message,
            (
                SELECT m.image_url FROM messages m
                WHERE (m.sender_id=u.id AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=u.id)
                ORDER BY m.id DESC LIMIT 1
            ) AS last_image,
            (
                SELECT m.created_at FROM messages m
                WHERE (m.sender_id=u.id AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=u.id)
                ORDER BY m.id DESC LIMIT 1
            ) AS last_time
        FROM users u
        WHERE u.id != ?
        ORDER BY (last_time IS NULL), last_time DESC, u.username
    """, (user["id"], user["id"], user["id"], user["id"], user["id"], user["id"], user["id"])).fetchall()

    conn.close()

    return jsonify({
        "success": True,
        "users": [
            {
                "id": row["id"],
                "username": row["username"],
                "full_name": row["full_name"],
                "avatar": row["avatar"],
                "last_message": row["last_message"],
                "last_image": bool(row["last_image"]),
                "last_time": row["last_time"]
            }
            for row in rows
        ]
    })


# ============================================================
# VIDEO CALL SIGNALING (polling-based, experimental)
# ============================================================

@app.route("/api/calls/signal", methods=["POST"])
def send_call_signal():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    data = request.get_json(silent=True) or {}
    to_id = data.get("to_id")
    signal_type = data.get("type")
    payload = data.get("payload")

    if not to_id or not signal_type or payload is None:
        return jsonify({"success": False, "message": "Invalid signal."}), 400

    conn = get_db()
    conn.execute("""
        INSERT INTO call_signals (from_id, to_id, signal_type, payload, created_at)
        VALUES (?, ?, ?, ?, ?)
    """, (user["id"], to_id, signal_type, json.dumps(payload), datetime.now().isoformat()))
    conn.commit()
    conn.close()

    return jsonify({"success": True})


@app.route("/api/calls/poll")
def poll_call_signals():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    since_id = request.args.get("since", 0, type=int)

    conn = get_db()
    rows = conn.execute("""
        SELECT id, from_id, signal_type, payload, created_at
        FROM call_signals
        WHERE to_id=? AND id > ?
        ORDER BY id ASC
    """, (user["id"], since_id)).fetchall()
    conn.close()

    return jsonify({
        "success": True,
        "signals": [
            {"id": r["id"], "from_id": r["from_id"], "type": r["signal_type"], "payload": json.loads(r["payload"])}
            for r in rows
        ]
    })


@app.route("/api/messages/<int:user_id>")
def get_messages(user_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()

    rows = conn.execute("""
        SELECT id, sender_id, receiver_id, message, image_url, created_at
        FROM messages
        WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)
        ORDER BY id ASC
    """, (user["id"], user_id, user_id, user["id"])).fetchall()

    conn.close()

    return jsonify({
        "success": True,
        "messages": [
            {
                "id": row["id"],
                "sender_id": row["sender_id"],
                "receiver_id": row["receiver_id"],
                "message": row["message"],
                "image_url": row["image_url"],
                "created_at": row["created_at"]
            }
            for row in rows
        ]
    })


@app.route("/api/messages", methods=["POST"])
def send_message():
    auth = login_required()
    if auth:
        return auth

    user = current_user()

    is_multipart = request.content_type and "multipart/form-data" in request.content_type

    if is_multipart:
        receiver_id = request.form.get("receiver_id")
        message = request.form.get("message", "").strip()
        image_file = request.files.get("image")
        shared_post_id = request.form.get("post_id")
    else:
        data = request.get_json(silent=True) or {}
        receiver_id = data.get("receiver_id")
        message = data.get("message", "").strip()
        image_file = None
        shared_post_id = data.get("post_id")

    image_url = ""

    if shared_post_id:
        conn0 = get_db()
        shared_post = conn0.execute("""
            SELECT p.media_url, p.caption, u.username
            FROM posts p JOIN users u ON u.id = p.user_id
            WHERE p.id=?
        """, (shared_post_id,)).fetchone()
        conn0.close()
        if not shared_post:
            return jsonify({"success": False, "message": "Post not found."}), 404
        image_url = shared_post["media_url"]
        if not message:
            message = f"Shared a post from @{shared_post['username']}"

    if image_file and image_file.filename:
        if not allowed_file(image_file.filename):
            return jsonify({"success": False, "message": "This file type is not allowed."}), 400
        extension = image_file.filename.rsplit(".", 1)[1].lower()
        filename = uuid.uuid4().hex + "." + extension
        safe_name = secure_filename(filename)
        image_file.save(os.path.join(UPLOAD_DIR, safe_name))
        image_url = "/uploads/" + safe_name

    if not receiver_id or (not message and not image_url):
        return jsonify({"success": False, "message": "Receiver and message or image are required."}), 400

    conn = get_db()
    receiver = conn.execute("SELECT id FROM users WHERE id=?", (receiver_id,)).fetchone()

    if not receiver:
        conn.close()
        return jsonify({"success": False, "message": "User not found."}), 404

    blocked_check = conn.execute("""
        SELECT 1 FROM blocked_users
        WHERE (user_id=? AND blocked_id=?) OR (user_id=? AND blocked_id=?)
    """, (user["id"], receiver_id, receiver_id, user["id"])).fetchone()

    if blocked_check:
        conn.close()
        return jsonify({"success": False, "message": "You can't message this user."}), 403

    conn.execute("""
        INSERT INTO messages (sender_id, receiver_id, message, image_url, created_at)
        VALUES (?, ?, ?, ?, ?)
    """, (user["id"], receiver_id, message, image_url, datetime.now().isoformat()))

    conn.execute("""
        INSERT INTO notifications (user_id, actor_id, notification_type, text, created_at)
        VALUES (?, ?, ?, ?, ?)
    """, (
        receiver_id, user["id"], "message",
        user["username"] + " sent you a message",
        datetime.now().isoformat()
    ))

    conn.commit()
    conn.close()

    return jsonify({"success": True})


# ============================================================
# NOTIFICATIONS
# ============================================================

@app.route("/api/notifications/unread-count")
def notifications_unread_count():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()
    count = conn.execute(
        "SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0", (user["id"],)
    ).fetchone()[0]
    conn.close()

    return jsonify({"success": True, "count": count})


@app.route("/api/notifications")
def notifications():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()

    rows = conn.execute("""
        SELECT n.id, n.actor_id, n.notification_type, n.text, n.is_read, n.created_at, u.username AS actor_username
        FROM notifications n
        LEFT JOIN users u ON u.id = n.actor_id
        WHERE n.user_id=?
        ORDER BY n.id DESC
        LIMIT 50
    """, (user["id"],)).fetchall()

    conn.execute("UPDATE notifications SET is_read=1 WHERE user_id=?", (user["id"],))
    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "notifications": [
            {
                "id": row["id"],
                "actor_id": row["actor_id"],
                "actor_username": row["actor_username"],
                "type": row["notification_type"],
                "text": row["text"],
                "is_read": bool(row["is_read"]),
                "created_at": row["created_at"]
            }
            for row in rows
        ]
    })


@app.route("/api/activity")
def activity_feed():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()

    likes_rows = conn.execute("""
        SELECT l.created_at, u.username, u.avatar, p.id AS post_id, p.media_url
        FROM likes l
        JOIN users u ON u.id = l.user_id
        JOIN posts p ON p.id = l.post_id
        WHERE l.user_id IN (SELECT following_id FROM follows WHERE follower_id=?)
        ORDER BY l.id DESC
        LIMIT 25
    """, (user["id"],)).fetchall()

    comments_rows = conn.execute("""
        SELECT c.created_at, u.username, u.avatar, c.comment, p.id AS post_id, p.media_url
        FROM comments c
        JOIN users u ON u.id = c.user_id
        JOIN posts p ON p.id = c.post_id
        WHERE c.user_id IN (SELECT following_id FROM follows WHERE follower_id=?)
        ORDER BY c.id DESC
        LIMIT 25
    """, (user["id"],)).fetchall()

    follows_rows = conn.execute("""
        SELECT f.created_at, u1.username AS follower_username, u1.avatar AS follower_avatar,
               u2.username AS target_username
        FROM follows f
        JOIN users u1 ON u1.id = f.follower_id
        JOIN users u2 ON u2.id = f.following_id
        WHERE f.follower_id IN (SELECT following_id FROM follows WHERE follower_id=?)
        ORDER BY f.id DESC
        LIMIT 25
    """, (user["id"],)).fetchall()

    conn.close()

    items = []
    for r in likes_rows:
        items.append({
            "type": "like", "created_at": r["created_at"], "username": r["username"], "avatar": r["avatar"],
            "text": f"{r['username']} liked a post", "media_url": r["media_url"], "post_id": r["post_id"]
        })
    for r in comments_rows:
        items.append({
            "type": "comment", "created_at": r["created_at"], "username": r["username"], "avatar": r["avatar"],
            "text": f"{r['username']} commented: {r['comment'][:40]}", "media_url": r["media_url"], "post_id": r["post_id"]
        })
    for r in follows_rows:
        items.append({
            "type": "follow", "created_at": r["created_at"], "username": r["follower_username"], "avatar": r["follower_avatar"],
            "text": f"{r['follower_username']} started following {r['target_username']}", "media_url": "", "post_id": None
        })

    items.sort(key=lambda x: x["created_at"], reverse=True)

    return jsonify({"success": True, "activity": items[:40]})


# ============================================================
# STORIES
# ============================================================

@app.route("/api/stories")
def get_stories():
    auth = login_required()
    if auth:
        return auth

    conn = get_db()
    rows = conn.execute("""
        SELECT s.id, s.user_id, s.media_url, s.media_type, s.music_url, s.music_name, s.created_at, u.username, u.avatar
        FROM stories s
        JOIN users u ON u.id=s.user_id
        WHERE datetime(s.expires_at) > datetime('now')
        ORDER BY s.id DESC
    """).fetchall()
    conn.close()

    return jsonify({
        "success": True,
        "stories": [
            {
                "id": row["id"],
                "user_id": row["user_id"],
                "username": row["username"],
                "avatar": row["avatar"],
                "media_url": row["media_url"],
                "media_type": row["media_type"],
                "music_url": row["music_url"] if "music_url" in row.keys() else "",
                "music_name": row["music_name"] if "music_name" in row.keys() else "",
                "created_at": row["created_at"]
            }
            for row in rows
        ]
    })


@app.route("/api/stories", methods=["POST"])
def create_story():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    file = request.files.get("file")
    music_file = request.files.get("music")

    if not file or file.filename == "":
        return jsonify({"success": False, "message": "Please select a photo or video."}), 400

    if not allowed_file(file.filename):
        return jsonify({"success": False, "message": "This file type is not allowed."}), 400

    extension = file.filename.rsplit(".", 1)[1].lower()
    filename = uuid.uuid4().hex + "." + extension
    safe_name = secure_filename(filename)
    path = os.path.join(UPLOAD_DIR, safe_name)
    file.save(path)

    media_type = "video" if file.mimetype.startswith("video/") else "image"
    media_url = "/uploads/" + safe_name

    music_url = ""
    music_name = ""
    if music_file and music_file.filename:
        allowed_audio = {"mp3", "wav", "ogg", "m4a"}
        m_ext = music_file.filename.rsplit(".", 1)[-1].lower() if "." in music_file.filename else ""
        if m_ext in allowed_audio:
            m_filename = uuid.uuid4().hex + "." + m_ext
            m_safe = secure_filename(m_filename)
            music_file.save(os.path.join(UPLOAD_DIR, m_safe))
            music_url = "/uploads/" + m_safe
            music_name = music_file.filename.rsplit(".", 1)[0][:60]

    now = datetime.now()
    expires = now + timedelta(hours=24)

    conn = get_db()
    conn.execute("""
        INSERT INTO stories (user_id, media_url, media_type, music_url, music_name, created_at, expires_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (user["id"], media_url, media_type, music_url, music_name, now.isoformat(), expires.isoformat()))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Story added."})


# ============================================================
# HIGHLIGHTS
# ============================================================

@app.route("/api/highlights/<username>")
def get_highlights(username):
    conn = get_db()
    target = conn.execute("SELECT id FROM users WHERE username=?", (username.lower(),)).fetchone()
    if not target:
        conn.close()
        return jsonify({"success": False, "message": "User not found."}), 404

    rows = conn.execute("""
        SELECT id, title, media_url, media_type, created_at
        FROM highlights
        WHERE user_id=?
        ORDER BY id DESC
    """, (target["id"],)).fetchall()
    conn.close()

    return jsonify({
        "success": True,
        "highlights": [
            {"id": r["id"], "title": r["title"], "media_url": r["media_url"], "media_type": r["media_type"]}
            for r in rows
        ]
    })


@app.route("/api/highlights", methods=["POST"])
def create_highlight():
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    title = request.form.get("title", "").strip()
    story_id = request.form.get("story_id")
    file = request.files.get("file")

    if not title:
        return jsonify({"success": False, "message": "Please give the highlight a title."}), 400

    conn = get_db()
    media_url = ""
    media_type = "image"

    if story_id:
        story = conn.execute(
            "SELECT media_url, media_type FROM stories WHERE id=? AND user_id=?",
            (story_id, user["id"])
        ).fetchone()
        if not story:
            conn.close()
            return jsonify({"success": False, "message": "Story not found."}), 404
        media_url = story["media_url"]
        media_type = story["media_type"]
    elif file and file.filename:
        if not allowed_file(file.filename):
            conn.close()
            return jsonify({"success": False, "message": "This file type is not allowed."}), 400
        extension = file.filename.rsplit(".", 1)[1].lower()
        filename = uuid.uuid4().hex + "." + extension
        safe_name = secure_filename(filename)
        file.save(os.path.join(UPLOAD_DIR, safe_name))
        media_url = "/uploads/" + safe_name
        media_type = "video" if file.mimetype.startswith("video/") else "image"
    else:
        conn.close()
        return jsonify({"success": False, "message": "Select a story or upload a file."}), 400

    conn.execute("""
        INSERT INTO highlights (user_id, title, media_url, media_type, created_at)
        VALUES (?, ?, ?, ?, ?)
    """, (user["id"], title, media_url, media_type, datetime.now().isoformat()))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Highlight added."})


@app.route("/api/highlights/<int:highlight_id>", methods=["DELETE"])
def delete_highlight(highlight_id):
    auth = login_required()
    if auth:
        return auth

    user = current_user()
    conn = get_db()
    h = conn.execute("SELECT user_id FROM highlights WHERE id=?", (highlight_id,)).fetchone()

    if not h:
        conn.close()
        return jsonify({"success": False, "message": "Highlight not found."}), 404

    if h["user_id"] != user["id"]:
        conn.close()
        return jsonify({"success": False, "message": "You can only delete your own highlights."}), 403

    conn.execute("DELETE FROM highlights WHERE id=?", (highlight_id,))
    conn.commit()
    conn.close()

    return jsonify({"success": True, "message": "Highlight removed."})


# ============================================================
# UPLOADS
# ============================================================

@app.route("/uploads/<filename>")
def uploaded_file(filename):
    from flask import send_from_directory
    return send_from_directory(UPLOAD_DIR, filename)


# ============================================================
# HEALTH
# ============================================================

@app.route("/api/health")
def health():
    conn = get_db()
    users = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    posts = conn.execute("SELECT COUNT(*) FROM posts").fetchone()[0]
    conn.close()

    return jsonify({
        "success": True,
        "status": "online",
        "database": "connected",
        "users": users,
        "posts": posts
    })


# ============================================================
# START
# ============================================================

if __name__ == "__main__":
    init_db()

    print("")
    print("=" * 60)
    print(" ORBIT SOCIAL MEDIA APP")
    print("=" * 60)
    print("")
    print(" Server: http://127.0.0.1:5000")
    print(" Database:", DB_PATH)
    print(" Uploads:", UPLOAD_DIR)
    print("")
    print(" Demo Accounts")
    print("-" * 60)
    print(" Rahul : rahul_dev / Rahul@123")
    print(" Sneha : sneha_creates / Sneha@123")
    print(" Aman  : aman.tech / Aman@123")
    print("")
    print("=" * 60)
    print("")

    debug_mode = os.environ.get("FLASK_DEBUG", "0") == "1"
    port = int(os.environ.get("PORT", 5000))

    app.run(
        host="0.0.0.0",
        port=port,
        debug=debug_mode
    )
